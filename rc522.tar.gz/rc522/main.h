/*
 * main.h
 *
 *  Created on: 26.09.2013
 *      Author: alexs
 */

#ifndef MAIN_H_
#define MAIN_H_

/* different routines in main.c */
int get_card_info();
int authorize(uint8_t *pSnr, int block, int auth_key);
int perform_action();
int change_con();
void close_out(int ex_code);
int get_card_info();
int get_card_permission(int addr);
int get_config_file();
int key_upd();
int read_card_to_file();
int read_from_card();
void usage(char * str);
int write_to_card();

extern uint8_t debug;
extern uint8_t SN[10];             // serial number of card
extern uint8_t SN_len;           // length of serial number ( 4/7/10)

#endif /* MAIN_H_ */
