/*
 * main.h
 *
 *  Created on: 26.09.2013
 *      Author: alexs
 */

#ifndef MAIN_H_
#define MAIN_H_

extern uint8_t debug;
extern uint8_t SN[10];             // serial number of card
extern uint8_t SN_len;           // length of serial number ( 4/7/10)

#endif /* MAIN_H_ */
