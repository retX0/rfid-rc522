/*
 * main.c
 *
 *  Created on: 14.08.2013
 *      authorizer: alexs
 *
 * paulvha / March 2016 / version 1.0
 * Based on the original RC522.c package, added functionality to
 * make it work and work easy.
 *
 * Original package could already:
 *  Execute a program based on the card serial number
 *  Display the card type and serial number
 *  Reading to file as included, but missed authentication to work
 *
 * It now can:
 *  Read a specific block and display content
 *  Read ALL blocks into a file (added the missing authentication)
 *  Write on specific block, specific data (+ check security)
 *  Add ability to set access bits on different blocks
 *  Add ability to change the KEYA or KEYB per sector/card and add to config file
 *  Additional command line options to control
 *
 *  + streamlined to program, added source code comments
 */
 
 /*
 * RFID-RC522 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * RFID-RC522 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with RFID-RC522.  If not, see <http://www.gnu.org/licenses/>.
 */

char VERSION[] = "1.0";

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/wait.h>
#include <signal.h>
#include "rfid.h"
#include "bcm2835.h"
#include "config.h"

#define B0B7C1 0X10 // B0 = block 0, B7 = Byte 7, C1 = condition 1
#define B0B8C2 0X01
#define B0B8C3 0X10

#define B1B7C1 0X20
#define B1B8C2 0X02
#define B1B8C3 0X20

#define B2B7C1 0X40
#define B2B8C2 0X04
#define B2B8C3 0X40

#define TB7C1 0X80  // T = Trailer, B7 = Byte 7, C1 = condition 1
#define TB8C2 0X08
#define TB8C3 0X80

#define REDSTR "\e[1;31m%s\e[00m"
#define GRNSTR "\e[1;92m%s\e[00m"
#define YLWSTR "\e[1;93m%s\e[00m"
#define BLUSTR "\e[1;34m%s\e[00m"

uint8_t debug=0;
uint8_t use_gpio=0;         // was valid GPIO for reset ?
uint8_t gpio=255;           // GPIO for reset
uint32_t spi_speed=1000000L; // speed for SP (4 < >125)
char    fmem_path[255];     // to hold the directory for memory save
char    save_mem=0;         // trigger to save card info
uint8_t SN[10];             // serial number of card
uint16_t CType=0;           // card type/ ATAQ response
uint8_t SN_len=0;           // length of serial number ( 4/7/10)
char    sn_str[23];         // to hold [serial]
char    str[255];           // read config file
uint8_t loop = 10, endless = 1; // main loop
int     max_page=0x3f;      // # of pages on card
uint8_t page_step=0;        // increment to read the card

// needed to prefent repeat authentication key check
int prev_sct_num=0;
int prev_auth_key=0;
uint8_t prev_sn[10];


/* perform init BCM and GPIO */

uint8_t HW_init(uint32_t spi_speed, uint8_t gpio) {
    uint16_t sp;

    sp=(uint16_t)(250000L/spi_speed);

    if (!bcm2835_init()) {
        syslog(LOG_DAEMON|LOG_ERR,"Can't init bcm2835!\n");
        return 1;
    }
    if (gpio<28) {         // reset RC522
        bcm2835_gpio_fsel(gpio, BCM2835_GPIO_FSEL_OUTP);

        // NRSTPD = low is OUT/power down]
        bcm2835_gpio_write(gpio, LOW);
        bcm2835_delay(500);

        // NRSTPD = positve edge is reset + run
        bcm2835_gpio_write(gpio, HIGH);
        bcm2835_delay(500);

    }

    bcm2835_spi_begin();    // set pins 19, 21, 23, 24, 26
    bcm2835_spi_setBitOrder(BCM2835_SPI_BIT_ORDER_MSBFIRST);      // The default
    bcm2835_spi_setDataMode(BCM2835_SPI_MODE0);                   // The default
    bcm2835_spi_setClockDivider(sp);                              // The default
    bcm2835_spi_chipSelect(BCM2835_SPI_CS0);                      // The default
    bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW);      // the default
    return 0;
}

/* restore and terminate program */
void close_out(int ex_code)
{
    if (use_gpio) bcm2835_gpio_write(gpio, LOW); // set reset
    bcm2835_spi_end();
    bcm2835_close();
    close_config_file();
    exit(ex_code);
}

void usage(char * str) {
    printf("Usage:\n%s [options]:           (version %s)\n",str,VERSION);
    printf("\t  -d  enable debug mode\n");
    printf("\t  -w  write to card block\n");
    printf("\t  -r  read a card block\n");
    printf("\t  -s  save content all card blocks in a file\n");
    printf("\t  -p  perform action on card number (specified in configuration file)\n");
    printf("\t  -c  change access rights for specific block\n");
    printf("\t  -a  perform action based on content specific block\n");
    printf("\t  -k  Change authentication key on a specific sector\n");
}

/* update key on specific sector */
int key_upd(){
    int             numb, addr = -1, t_addr;
    unsigned char   ch = 'n', key = 'c';
    int             i, j, tmp, lp = 1;
    int             sct_num = -1;
    uint8_t         buff[50];
    char            buf[50], *p;
    uint8_t         new_key[6];

    do
    {
        printf (YLWSTR,"Do you want to provide s = sector or b = block number for key-update ", max_page);
        scanf("%c", &ch);

        if ((ch =='s') || (ch == 'S'))  i = 1;
        else if ((ch =='b') || (ch == 'B')) i = 2;
        else {
            printf(REDSTR,"Invalid entry  's' or 'b'\n");
            ch = 'n';
        }
        // flush any input pending
        while ((tmp=getchar()) != '\n' && tmp != EOF);

    } while (ch == 'n');

    if (i == 2){

        do    // get valid block
        {
            sprintf (buf,"Provide block where to update sector key. (Max %d) : ", max_page);
            printf(YLWSTR,buf);
            scanf("%d", &addr);

            if (addr > max_page) {
                sprintf (buf,"Block number is to high %2d. Maximum %d\n",addr, max_page);
                printf(REDSTR,buf);
                addr = -1;

            }
            else if (addr < 0){
                printf(REDSTR,"Block can't be below 0.\n");
                addr = -1;
            }

            // flush any input pending
            while ((ch=getchar()) != '\n' && ch != EOF);

        } while (addr == -1);

        // determine sct_num
        tmp = addr;
        sct_num = 0;
        while(tmp > 3){
            sct_num++;
            tmp -= 4;
        }
    }
    else
    {
        do    // get valid sector
        {
            printf (YLWSTR,"Please provide the sector to update key. (0 - 15) : ");
            scanf("%d", &sct_num);

            if (sct_num == 99)  close_out(0);

            if ((sct_num < 0) || (sct_num > 15))
            {
                printf(REDSTR,"Invalid sct_num number. Please try again.\n");
                sct_num = -1;
            }

            // flush any input pending
            while ((ch=getchar()) != '\n' && ch != EOF);

        } while (sct_num == -1);
        addr = sct_num * 4;
     }

    do    // get key A or B
    {
        printf (YLWSTR,"Which key do you want to update A = KEYA or B = KEYB) : ");
        scanf("%c", &key);

        if ((key == 'e')|| (key =='E'))  close_out(0);

        key = toupper(key);

        if ((key != 'A') &&  (key != 'B'))
        {
            printf(REDSTR,"Invalid key. Please try again.\n");
            key = 'c';
        }

        // flush any input pending
        while ((ch=getchar()) != '\n' && ch != EOF);

    } while (key == 'c');

    // get the new key
    for (i=0 ; i < 6; i++)
    {
        tmp=0;
        do
        {
            sprintf(buf,"Provide authentication byte %2d of 6 : 0x",i+1);
            printf (YLWSTR,buf);

            tmp = scanf("%x", &new_key[i]);

            if (tmp == 0)
                printf(REDSTR,"Invalid entry. Try again.\n");

            // flush any input pending
            while ((ch=getchar()) != '\n' && ch != EOF);

        } while (tmp == 0);

    }

    // printf("sector outcome %d\n",sct_num);
    // get confirmation

    i = 0;
    j = sct_num;
    while (j-- > 0) i += 4;
    printf (GRNSTR,"******** IMPORTANT TO DOUBLE CHECK ***************\n");
    printf (GRNSTR,"You are about to make a change to :\n");
    sprintf (buf,"Sector %d, with the block range of %d - %d\n",sct_num, i,i+3);
    printf (GRNSTR,buf);
    sprintf (buf,"Update authentication KEY%c to ",key);
    printf (GRNSTR,buf);

    for (i=0 ; i < 6; i++)  printf("\e[1;92m%2x ",new_key[i]);
    i=0;
    do
    {
        printf(YLWSTR,"\nIs the correct (yes, no or exit) ? ");
        scanf("%s", &buf);

        if (strcasecmp(buf,"no") == 0)
            return(0);

        else if (strcasecmp(buf,"yes") == 0)
             i=1;

        else if (strcasecmp(buf,"exit") == 0)
             close_out(0);

        else
            printf(REDSTR,"Invalid answer. Please type 'yes' or 'no' \n");

    }   while (i == 0);

    // wait for card
    if (get_card_info() != TAG_OK)    return(1);

    printf(REDSTR,"**********************************************\n");
    printf(REDSTR,"  DO NOT REMOVE YOUR CARD FROM THE READER !!\n");
    printf(REDSTR,"**********************************************\n\n");

    // determine memory details
    switch (CType) {
        case 0x4400:           // 16 blocks of 8 bytes
            max_page=0x0f;
            break;
        case 0x0400:           // 64 blocks of 8 bytes / Ul card
            max_page=0x3f;
            break;
        default:
            printf("Card type not known. Do you want to continue ? ( y/n ) ");
            scanf("%c",&ch);

            if ((ch != 'y') && (ch != 'Y')){
                PcdHalt();
                printf(GRNSTR,"You can remove the card\n");
                return(0);
            }
            break;
    }

    // check block fit
    if (addr > max_page) {
        printf("This card has only %d blocks. Can not read from %d.\n",max_page, addr);
        PcdHalt();
        return(0);
    }

    // determine access rights : access trailer
    tmp = addr;
    t_addr = 3;

    while (tmp > 3)             // determine block trailer
    {
          t_addr += 4;
          tmp -= 4;
    }

    if (authorize(SN, t_addr,PICC_AUTHENT1A) != TAG_OK) return(1);

    if (PcdRead(t_addr,buff) != TAG_OK){       // read trailer
        sprintf(buf,"Error during reader trailer. %d\n",addr);
        printf(REDSTR,buf);
        return(1);
    }

    /* as we authenticate with KEYA and if we do NOT update KEYB, we have
     * to get the current valid KEYB for this sector first to write back.
     */
    if (key == 'A'){
        if (read_conf_key(t_addr,PICC_AUTHENT1B) != 0){
            sprintf(buf,"Error during obtaining current KEYB for sector %d\n",sct_num);
            printf(REDSTR,buf);
            return(1);
        }
    }

    // add keys
    for (i = 0;i< sizeof(KEYA);i++){
            if (key == 'A')
            {
                buff[i] = new_key[i];
                buff[i+10] = KEYB[i];
            }
            else
            {
                buff[i] = KEYA[i];
                buff[i+10] = new_key[i];
            }
         }

    if (debug){
        printf("New trailer to be written : ");
        for (i = 0;i<16;i++)
            printf("%02x",buff[i]);
        printf("\n");
    }

    // update trailer
    if (PcdWrite(t_addr, buff) != TAG_OK){
        printf(REDSTR,"Error during update trailer.\n");
        PcdHalt();
        return(1);
    }

    // read back to double check
    if (debug)
    {   read_tag_str(t_addr,buff);
        printf("Trailer %d has been read and has the following content %s\n",t_addr, buff);
    }

    // close / disconnect the card
    PcdHalt();
    sprintf(buf,"KEY%c has been updated. You can remove the card\n",key);
    printf(GRNSTR,buf);
    sprintf(buf,"Make sure to write down the new code KEY%c : ",key);
    printf(GRNSTR,buf);
    for (i=0 ; i < 6; i++)  printf("\e[1;93m%2x ",new_key[i]);
    printf(REDSTR,"\nOtherwise access to this sector is lost and can not be recovered\n");


    p=buf;
    // create search key
    *(p++) = '#';               // set as comment
    *(p++) = '[';               // start with [
    sprintf(p,"%02d",sct_num);  // add sector
    p += 2;
    *(p++) = key;               // add key
    *(p++) = '{';               // add {

    // serial number
    for(i = 0; i < SN_len;i++)
    {
        sprintf(p,"%02x",SN[i]);
        p += 2;
    }
    *(p++) = '}';               // add separator

    for(i = 0; i < 6;i++)       // add new key
    {
        sprintf(p,"%02x ",new_key[i]);
        p += 3;
    }
    p--;
    *(p++) = ']';               // add trailer
    *(p++) = 0;

    if (add_to_config(buf)){
        sprintf(buff,"Error during adding to config file %s: %s\n",config_file, buf);
        printf(REDSTR,buff);
        printf(REDSTR,"Write down this code and add manually (without leading #)\n");
        return(1);
    }

    printf("An entry %s has been added to the config file %s\n", buf, config_file);
    printf("It is the last line and you need to remove the '#' manually to make it valid.\n");
    return(0);
}
/* Get authorization to access memory
 * snr = buffer with serial number
 * block = block to get access to
 * auth_key = use KEYA (PICC_AUTHENT1A) or KEYB (PICC_AUTHENT1B)
 *
 *
 * */

int authorize(uint8_t *pSnr, int block, int auth_key)
{
    int status=0;
    int i;
    uint8_t *p;
    int get_key = 1;
    int sct_num=0;

    // determine sct_num
    i = block;
    while(i > 3){
        sct_num++;
        i -= 4;
    }
    // do we need to retrieve the code again ?

    if (sct_num == prev_sct_num)            // same block before ?

        if (auth_key == prev_auth_key)    // for same key (A or B) ?
        {
            p=pSnr;                       // same serial number ?
            for (i=0; i<SN_len; i++)
                if (prev_sn[i] != *(p++))
                        break;

            if (i == SN_len) get_key = 0;
        }
    //printf("get key %d, sct_num %d, block %d\n",get_key,sct_num,block);
    if (get_key)
    {
            status = read_conf_key(block, auth_key);

            if (status) {
                printf(REDSTR,"Issue with obtaining authentication key !!!! \n");
                return(status);
            }
            else{
                prev_sct_num = sct_num;
                prev_auth_key = auth_key;
                p=pSnr;
                for (i=0;i <SN_len;i++)
                    prev_sn[i]= *(p++);
            }
    }

    if (auth_key == PICC_AUTHENT1A)
        status = PcdAuthState(PICC_AUTHENT1A,block,KEYA,pSnr);

    else
        status = PcdAuthState(PICC_AUTHENT1B,block,KEYB,pSnr);

    if (status != TAG_OK){
        printf(REDSTR,"Authentification error !!!! \n");
        prev_auth_key = 0;      // force recapture of key next time
    }
    return(status);
}

/* read the config file information */

int get_config_file()
{
    if (open_config_file(config_file)!=0) {
        fprintf(stderr,"Can't open config file! (need read/write permissions)");
        return(1);
    }
    if (find_config_param("GPIO=",str,sizeof(str)-1,1)==1) {
        gpio=(uint8_t)strtol(str,NULL,10);

        if (gpio<28) {
            use_gpio=1;
        } else {
            gpio=255;
            use_gpio=0;
        }
    }
    if (find_config_param("SPI_SPEED=",str,sizeof(str)-1,1)==1) {
        spi_speed=(uint32_t)strtoul(str,NULL,10);
        if (spi_speed>125000L) spi_speed=125000L;
        if (spi_speed<4) spi_speed=4;
    }

    if (find_config_param("NEW_TAG_PATH=",fmem_path,sizeof(fmem_path)-1,0)) {

        if (fmem_path[strlen(fmem_path)-1]!='/')
            sprintf(&fmem_path[strlen(fmem_path)],"/");

        if (strlen(fmem_path)>=240) {
            fprintf(stderr,"Too long path for tag dump files!");
            save_mem = 0;
            return(1);
         }
    }
    else
        save_mem = 0;

    if (find_config_param("LOOP=",str,sizeof(str)-1,1)==1) {
        loop=(uint8_t)strtol(str,NULL,10);

        if (loop < 0)       loop = 1;
        else if (loop > 0)  endless = 0;            // not endless
    }
    return(0);
}

/* wait and read card permission for block */
int get_card_permission(int addr)
{

    int             numb, t_addr;
    unsigned char   ch;
    int             i, tmp, lp = 1;
    uint8_t         buff[100];

    // wait for card
    if (get_card_info() != TAG_OK)    return(-1);

    // determine memory details
    switch (CType) {
        case 0x4400:           // 16 blocks of 8 bytes
            max_page=0x0f;
            page_step=4;        // increment to read the card
            break;
        case 0x0400:           // 64 blocks of 16 bytes / classic card
            max_page=0x3f;
            page_step=1;       // increment to read the card
            break;
        default:
            page_step=1;       // increment to read the card
            printf(YLWSTR,"Card type not known. Do you want to continue ? ( y/n ) ");
            scanf("%c",&ch);

            if ((ch != 'y') || (ch != 'Y')){
                PcdHalt();
                return(-1);
            }
            break;
    }

    // check block fit
    if (addr > max_page) {
        printf(buff,"This card has only %d blocks. Can not access %d.\n",max_page, addr);
        printf(REDSTR,buff);
        PcdHalt();
        return(-1);
    }

    // determine access rights : access trailer
    tmp = addr;
    t_addr = 3;

    while (tmp > 3)             // determine block trailer
    {
          t_addr += 4;
          tmp -= 4;
    }

    if (authorize(SN, t_addr,PICC_AUTHENT1A) != TAG_OK) return(1);

    if (PcdRead(t_addr,buff) != TAG_OK){       // read trailer
        printf(buff,"Error during reader trailer %d\n",addr);
        printf(REDSTR,buff);
        return(1);
    }

    i = 3 -(t_addr-addr);        // offset  -------------- access bits --------------------
                                // C1                      C2                           C3
    if (i == 0)         ch = (buff[7] & B0B7C1) >> 4 | (buff[8] & B0B8C2) << 1 | (buff[8] & B0B8C3) >> 2;
    else if (i == 1)    ch = (buff[7] & B1B7C1) >> 5 | (buff[8] & B1B8C2) << 0 | (buff[8] & B1B8C3) >> 3;
    else if (i == 2)    ch = (buff[7] & B2B7C1) >> 6 | (buff[8] & B2B8C2) >> 1 | (buff[8] & B2B8C3) >> 4;
    else if (i == 3)    ch = (buff[7] & TB7C1) >> 7  | (buff[8] & TB8C2) >> 2  | (buff[8] & TB8C3) >> 5;
    else {
        printf(REDSTR,"Issue with analysing trailer.\n");
        PcdHalt();
        return(-1);
    }
    return(ch);
}

/* perform action based on content specific block
 * action is defined in rc522.conf as [@code] */

int addr_action(){

    int             addr = -1;
    unsigned char   ch;
    int             tmp;
    uint8_t         buff[50];
    char            *p;

    do    // get valid block
    {
        sprintf (buff,"Please provide the block number to read action-code. (Max %d) : ", max_page);
        printf(YLWSTR,buff);
        scanf("%d", &addr);

        if (addr == 99)  close_out(0);

        if (addr > max_page) {
            sprintf(buff,"Block number is to high %2d. Maximum %d.\n",addr, max_page);
            printf(REDSTR,buff);
            addr = -1;

        }
        else if (addr < 0){
            sprintf(buff,"Block can't be below 0.\n");
            printf(REDSTR,buff);
            addr = -1;
        }

        else if ((addr == 3) || (! ((addr-3) % 4))){
            sprintf (buff,"Can not use a trailer location.\n");
            printf(REDSTR,buff);
            addr = -1;
        }
        // flush any input pending
        while ((ch=getchar()) != '\n' && ch != EOF);

    } while (addr == -1);

    ch = get_card_permission(addr);

    if (ch < 0) return(1);

    // as we use keyA for access, bit 1 should not be set, unless the value is 1
    // see MF1IC520 card description.

    if ((ch &0x01) && (ch != 1) ){
        sprintf(buff,"Block %d has no read permission. (code: %x) \n", addr,ch);
        printf(REDSTR,buff);
        PcdHalt();
        return(1);
    }

    // access memory block
    if (authorize(SN, addr,PICC_AUTHENT1A) != TAG_OK){
        PcdHalt();
        return(1);
    }

    // read block
    if (read_tag_str(addr,buff) != TAG_OK){
        sprintf(buff,"Error during reading %d\n",addr);
        printf(REDSTR,buff);
        PcdHalt();
        return(1);
    }

    PcdHalt();

    // create command string
    p=sn_str;
    *(p++)='[';                     // start with [
    *(p++)='@';                     // add @ to make distinction to sen.
    for (tmp=0;tmp<16;tmp++) {      // add block content

       if (buff[tmp] == '0')       // value must be more then 0
            continue;

       *(p++)=buff[tmp];
    }
    *(p++)=']';                     // close out with ]
    *(p++)=0;

    if (debug){
        printf("\nBlock : %d has the following content %s.\n",addr,buff);
        printf("\nCommand string is %s.\n",sn_str);
    }

    if (strlen(sn_str) < 3){
        printf(buff,"Not enough action-code characters on block %s.\n",sn_str);
        printf(REDSTR,buff);
        return(1);
    }
    // now search and execute command
    return(perform_action());
}

/* change access conditions for a specific block from the card */

int change_con() {

    int             numb, addr = -1, t_addr;
    unsigned char   ch;
    int             i, tmp, lp = 1;
    uint8_t         buff[100];

    do    // get valid block
    {
        sprintf (buff,"Please provide the block to update access rights. (Max %d) : ", max_page);
        printf(YLWSTR,buff);
        scanf("%d", &addr);

        if (addr == 99)  close_out(0);

        if (addr > max_page) {
            sprintf(buff,"Block number is to high %2d. Maximum %d\n",addr, max_page);
            printf(REDSTR,buff);
            addr = -1;

        }
        else if (addr < 0){
            printf(REDSTR"Block can't be below 0.\n");
            addr = -1;
        }

        else if ((addr == 3) || (! ((addr-3) % 4))){
            printf (REDSTR"Can not change access to trailer.\n");
            addr = -1;
        }
        // flush any input pending
        while ((ch=getchar()) != '\n' && ch != EOF);

    } while (addr == -1);

    // wait for card
    if (get_card_info() != TAG_OK)    return(1);

    printf(REDSTR,"**********************************************\n");
    printf(REDSTR,"  DO NOT REMOVE YOUR CARD FROM THE READER !!\n");
    printf(REDSTR,"**********************************************\n\n");

    // determine memory details
    switch (CType) {
        case 0x4400:           // 16 blocks of 8 bytes
            max_page=0x0f;
            break;
        case 0x0400:           // 64 blocks of 8 bytes / Ul card
            max_page=0x3f;
            break;
        default:
            printf(YLWSTR,"Card type not known. Do you want to continue ? ( y/n ) ");
            scanf("%c",&ch);

            if ((ch != 'y') && (ch != 'Y')){
                PcdHalt();
                printf(GRNSTR,"You can remove the card\n");
                return(0);
            }
            break;
    }

    // check block fit
    if (addr > max_page) {
        sprintf(buff,"This card has only %d blocks. Can not read from %d.\n",max_page, addr);
        printf(REDSTR,buff);
        PcdHalt();
        return(0);
    }

    // determine access rights : access trailer
    tmp = addr;
    t_addr = 3;

    while (tmp > 3)             // determine block trailer
    {
          t_addr += 4;
          tmp -= 4;
    }

    if (authorize(SN, t_addr,PICC_AUTHENT1A) != TAG_OK) return(1);

    if (PcdRead(t_addr,buff) != TAG_OK){       // read trailer
        sprintf(buff,"Error during reader trailer %d\n",addr);
        printf(REDSTR,buff);
        return(1);
    }

    i = 3 -(t_addr-addr);        // offset  -------------- access bits --------------------
                                 // C1                      C2                           C3
    if (i == 0)         tmp = (buff[7] & B0B7C1) >> 4 | (buff[8] & B0B8C2) << 1 | (buff[8] & B0B8C3) >> 2;
    else if (i == 1)    tmp = (buff[7] & B1B7C1) >> 5 | (buff[8] & B1B8C2)      | (buff[8] & B1B8C3) >> 3;
    else if (i == 2)    tmp = (buff[7] & B2B7C1) >> 6 | (buff[8] & B2B8C2) >> 1 | (buff[8] & B2B8C3) >> 4;
    else {
        printf(REDSTR,"Issue with analysing trailer.\n");
        PcdHalt();
        return(1);
    }

    printf (YLWSTR,"\nCurrent access permission for this block:\n ");
    printf ("\tread\twrite\tincrement\tdecrement,\n\t\t\t\t\ttransfer,\n\t\t\t\t\trestore\n");
    if (tmp == 0){
        printf("----------------------------------------------------------------------------\n");
        printf(YLWSTR,"| 0.\tkeyA|B\tkeyA|B\tkeyA|B\t\tkeyA|B\t   (transport configuration)\n");
        printf("----------------------------------------------------------------------------\n");
    } else
        printf("  0.\tkeyA|B\tkeyA|B\tkeyA|B\t\tkeyA|B\t(transport configuration)\n");

    if (tmp == 1){
       printf("----------------------------------------------------------------------------\n");
        printf(YLWSTR,"| 1.\tkeyA|B\tnever\tnever\t\tDecrement\t(value block)\n");
        printf("----------------------------------------------------------------------------\n");
    } else
        printf("  1.\tkeyA|B\tnever\tnever\t\tDecrement\t(value block)\n");

    if (tmp == 2){
        printf("----------------------------------------------------------------------------\n");
        printf(YLWSTR,"| 2.\tkeyA|B\tnever\tnever\t\tnever\t\t(read/write block)\n");
        printf("----------------------------------------------------------------------------\n");
    } else
        printf("  2.\tkeyA|B\tnever\tnever\t\tnever\t\t(read/write block)\n");

    if (tmp == 3){
        printf("----------------------------------------------------------------------------\n");
        printf("YLWSTR","| 3.\tkeyB\tkeyB\tnever\t\tnever\t\t(read/write block)\n");
        printf("----------------------------------------------------------------------------\n");
    } else
        printf("  3.\tkeyB\tkeyB\tnever\t\tnever\t\t(read/write block)\n");

    if (tmp == 4){
        printf("----------------------------------------------------------------------------\n");
        printf(YLWSTR,"| 4.\tkeyA|B\tnever\tnever\t\tnever\t\t(read/write block)\n");
        printf("----------------------------------------------------------------------------\n");
    } else
        printf("  4.\tkeyA|B\tnever\tnever\t\tnever\t\t(read/write block)\n");

     if (tmp == 5){
        printf("----------------------------------------------------------------------------\n");
        printf(YLWSTR,"| 5.\tkeyB\tnever\tnever\t\tnever\t\t(read/write block)\n");
        printf("----------------------------------------------------------------------------\n");
    } else
        printf("  5.\tkeyB\tnever\tnever\t\tnever\t\t(read/write block)\n");

     if (tmp == 6){
        printf("----------------------------------------------------------------------------\n");
        printf(YLWSTR,"| 6.\tRecharge only with KeyB \t\t\t\t(value block)\n");
        printf("----------------------------------------------------------------------------\n");
    } else
        printf("  6.\t\tRecharge on with KeyB \t\t\t(value block)\n");

     if (tmp == 7){
        printf("----------------------------------------------------------------------------\n");
        printf(YLWSTR,"| 7.\tnever\tnever\tnever\t\tnever\t\t(read/write block)\n");
        printf("----------------------------------------------------------------------------\n");
    } else
        printf("  7.\tnever\tnever\tnever\t\tnever\t\t(read/write block)\n");

    ch = '8';
    do          // Ask new access right
    {
        printf ("\nDo you want to change ?\nEnter 'n' for NO change or choose number of access right wanted. ");
        scanf("%c",&ch);

        if ((ch == 'n') || (ch == 'N')){
            PcdHalt();
            printf(GRNSTR,"Abort update. You can remove the card\n");
            return(0);
        }

        if ((ch < '0') || (ch > '7')){
            printf ("Invalid entry. Try again. %d\n", ch);
            ch = '8';
        }
    }  while (ch == '8');

    if (debug) printf("Before Byte 7: %x Byte 8 %x\n", buff[7], buff[8]);

    switch(ch){     // update Byte 7 & 8
            case 0x30:
                if (i == 0) {
                    buff[7] = buff[7] & ~B0B7C1;
                    buff[8] = buff[8] & ~B0B8C2;
                    buff[8] = buff[8] & ~B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] & ~B1B7C1;
                    buff[8] = buff[8] & ~B1B8C2;
                    buff[8] = buff[8] & ~B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] & ~B2B7C1;
                    buff[8] = buff[8] & ~B2B8C2;
                    buff[8] = buff[8] & ~B2B8C3;
                }
                break;
            case 0x31:
                if (i == 0) {
                    buff[7] = buff[7] | B0B7C1;
                    buff[8] = buff[8] & ~B0B8C2;
                    buff[8] = buff[8] & ~B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] | B1B7C1;
                    buff[8] = buff[8] & ~B1B8C2;
                    buff[8] = buff[8] & ~B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] | B2B7C1;
                    buff[8] = buff[8] & ~B2B8C2;
                    buff[8] = buff[8] & ~B2B8C3;
                }
                break;
            case 0x32:
                if (i == 0) {
                    buff[7] = buff[7] & ~B0B7C1;
                    buff[8] = buff[8] | B0B8C2;
                    buff[8] = buff[8] & ~B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] & ~B1B7C1;
                    buff[8] = buff[8] | B1B8C2;
                    buff[8] = buff[8] & ~B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] & ~B2B7C1;
                    buff[8] = buff[8] | B2B8C2;
                    buff[8] = buff[8] & ~B2B8C3;
                }

                break;
            case 0x33:
                            if (i == 0) {
                    buff[7] = buff[7] | B0B7C1;
                    buff[8] = buff[8] | B0B8C2;
                    buff[8] = buff[8] & ~B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] | B1B7C1;
                    buff[8] = buff[8] | B1B8C2;
                    buff[8] = buff[8] & ~B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] | B2B7C1;
                    buff[8] = buff[8] | B2B8C2;
                    buff[8] = buff[8] & ~B2B8C3;
                }
                break;
            case 0x34:
                if (i == 0) {
                    buff[7] = buff[7] & ~B0B7C1;
                    buff[8] = buff[8] & ~B0B8C2;
                    buff[8] = buff[8] | B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] & ~B1B7C1;
                    buff[8] = buff[8] & ~B1B8C2;
                    buff[8] = buff[8] | B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] & ~B2B7C1;
                    buff[8] = buff[8] & ~B2B8C2;
                    buff[8] = buff[8] | B2B8C3;
                }
                break;
            case 0x35:
                if (i == 0) {
                    buff[7] = buff[7] | B0B7C1;
                    buff[8] = buff[8] & ~B0B8C2;
                    buff[8] = buff[8] | B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] | B1B7C1;
                    buff[8] = buff[8] & ~B1B8C2;
                    buff[8] = buff[8] | B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] | B2B7C1;
                    buff[8] = buff[8] & ~B2B8C2;
                    buff[8] = buff[8] | B2B8C3;
                }
                break;
            case 0x36:
                if (i == 0) {
                    buff[7] = buff[7] & ~B0B7C1;
                    buff[8] = buff[8] | B0B8C2;
                    buff[8] = buff[8] | B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] & ~B1B7C1;
                    buff[8] = buff[8] | B1B8C2;
                    buff[8] = buff[8] | B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] & ~B2B7C1;
                    buff[8] = buff[8] | B2B8C2;
                    buff[8] = buff[8] | B2B8C3;
                }
                break;
            case 0x37:
                if (i == 0) {
                    buff[7] = buff[7] | B0B7C1;
                    buff[8] = buff[8] | B0B8C2;
                    buff[8] = buff[8] | B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] | B1B7C1;
                    buff[8] = buff[8] | B1B8C2;
                    buff[8] = buff[8] | B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] | B2B7C1;
                    buff[8] = buff[8] | B2B8C2;
                    buff[8] = buff[8] | B2B8C3;
                }
                break;
        }

    // set inverted
    buff[6] = buff[7] >> 4;             // C1
    buff[6] = buff[6] | (buff[8] << 4); // C2
    buff[6] = ~buff[6];                 // invert

    buff[7] = buff[7] & 0xf0;
    buff[7] = buff[7] | ((~buff[8] >> 4) & 0x0f);   //~c3

    // add keys
    for (i = 0;i< sizeof(KEYA);i++){
             buff[i] = KEYA[i];
             buff[i+10] = KEYB[i];
         }

    if (debug){
        printf("New trailer to be written : ");
        for (i = 0;i<16;i++)
            printf("%02x",buff[i]);
        printf("\n");
    }
    // update trailer
    if (PcdWrite(t_addr, buff) != TAG_OK){
        printf("Error during writing trailer %d.\n", t_addr);
        PcdHalt();
        return(1);
    }

    // read back to double check
    if (debug)
    {   read_tag_str(t_addr,buff);
        printf("Trailer %d has been read and has the following content %s\n",t_addr, buff);
    }

    // close / disconnect the card
    PcdHalt();
    printf(GRNSTR,"Permissions have been updated. You can remove the card\n");
    return(0);
}
/* read a specific block from the card */

int read_from_card(){

    int     i,numb, addr = -1, t_addr;
    unsigned char   ch;
    int     tmp, lp = 1;
    uint8_t buff[50];

    do    // get valid block
    {
        sprintf (buff,"Please provide the block to read. (Max %d) : ", max_page);
        printf(YLWSTR,buff);
        scanf("%d", &addr);

        if (addr == 99)  close_out(0);

        if (addr > max_page) {
            sprintf(buff,"Block number is to high %2d. Maximum %d\n",addr, max_page);
            printf(REDSTR,buff);
            addr = -1;

        } else if (addr < 0){
            printf(REDSTR,"Block can't be below 0.\n");
            addr = -1;
        }

        // flush any input pending
        while ((ch=getchar()) != '\n' && ch != EOF);

    } while (addr == -1);

    ch = get_card_permission(addr);

    if (ch < 0) return(1);

    // as we use keyA for access, bit 1 should not be set, unless the value is 1
    // see MF1IC520 card description.

    if ((ch &0x01) && (ch != 1) ){
        sprintf(buff,"The block %d has no read permission. (%x) \n", addr,ch);
        printf(REDSTR,buff);
        PcdHalt();
        return(1);
    }

    // access memory block
    if (authorize(SN, addr,PICC_AUTHENT1A) != TAG_OK) return(1);

    // read block
    read_tag_str(addr,buff);
    printf("\nBlock : %d has content %s\n",addr,buff);

    // close / disconnect the card
    PcdHalt();
    return(0);
}

/* write to specific block on the card */
int write_to_card(){

    int             numb, addr = -1, t_addr;
    unsigned char   ch;
    uint8_t         value[20], buff[50];
    int             i, tmp, lp = 1;

    do    // get valid block
    {
        sprintf (buff,"Please provide the block to write to (Max %d) : ", max_page);
        printf(YLWSTR,buff);
        scanf("%d", &addr);

        if (addr == 99)  close_out(0);

        if (addr > max_page) {
            sprintf(buff,"Block number is to high %2d. Maximum %d\n",addr, max_page);
            printf(REDSTR,buff);
            addr = -1;

        } else if (addr < 1){
            printf(REDSTR,"Block can't be below 1.\n");
            addr = -1;
        }

        else if ((addr == 3) || (! ((addr-3) % 4))){
            printf (REDSTR,"Can not write to trailer.\n");
            addr = -1;
        }

        // flush any input pending
        while ((ch=getchar()) != '\n' && ch != EOF);

    } while (addr == -1);

    do    // get valid value
    {
        // clear buffer
        for(i=0; i < 20 ; i++)  value[i]=0x0;

        printf (YLWSTR,"How many bytes you like to store (max 16 bytes) :");
        scanf("%d",&numb);

        // flush any input pending
        while ((ch=getchar()) != '\n' && ch != EOF);

        if ((numb < 0) || (numb > 16))
        {
            printf(REDSTR,"Incorrect number of bytes. Try again.\n");
            continue;
        }

        for (i=0 ; i < numb; i++)
        {
            tmp=0;
            do
            {
                printf ("Provide byte %2d : 0x",i);

                tmp = scanf("%x", &value[i]);

                if (tmp == 0)
                    printf(REDSTR,"Invalid entry. Try again.\n");

                // flush any input pending
                while ((ch=getchar()) != '\n' && ch != EOF);

            } while (tmp == 0);
        }

        printf (GRNSTR,"You entered : ");
        for (i=0 ; i< numb; i++)  printf ("0x%x ",value[i]);

        printf(YLWSTR,"\nIs this corrrect (y or n) ? ");
        scanf("%c",&ch);
        if ((ch == 'y') || (ch == 'Y'))  lp = 0;

    } while (lp); // get value

    ch = get_card_permission(addr);

    if (ch < 0) return(1);

    // as we use keyA for access, the only value is 0x0
    if (ch != 0){
        sprintf(buff,"The block %d has no write permission. (%x) \n", addr,ch);
        printf(REDSTR,buff);
        PcdHalt();
        return(1);
    }

    // access memory block
    if (authorize(SN, addr,PICC_AUTHENT1A) != TAG_OK) return(1);

    // perform write
    if (PcdWrite(addr, value) != TAG_OK){
        printf(REDSTR,"Error during writing.\n");
        PcdHalt();
        return(1);
    }

    // read back to double check
    read_tag_str(addr,buff);
    printf("Block %d: now has the following content %s.\n",addr, buff);

    // close / disconnect the card
    PcdHalt();
    return(0);
}
/* read card into a temp-file */

read_card_to_file()
{
    FILE    * fmem_str;            // saving card information
    char    file_str[255];         // save filename
    char    err_str[70];            //display error
    char    *p;
    char    status;
    int     lp,errcnt=0;

    p=file_str;
    sprintf(p,"%s",fmem_path);      // copy Path
    p+=strlen(p);
    for (lp=0;lp<SN_len;lp++) {     // add serial number
        sprintf(p,"%02x",SN[lp]);
        p+=2;
    }
    sprintf(p,".txt");              // add .txt

    if ((fmem_str=fopen(file_str,"r"))!= NULL) {
        sprintf(err_str,"Not saving. File exists %s\n",file_str);
        printf(REDSTR,err_str);
        fclose(fmem_str);
        return(TAG_OK);
    }                               // Try to create file

    if ((fmem_str=fopen(file_str,"w"))== NULL)
    {
        sprintf(err_str,"Not saving. Can not open for writing %s\n",file_str);
        printf(REDSTR,err_str);
        status=TAG_ERR;
    }
    else
    {
                                     // save card memory
        printf(REDSTR,"\n****************************************\n");
        printf(REDSTR,"  Started reading... do not remove card.\n");
        printf(REDSTR,"****************************************\n\n");

        status=TAG_OK;

        for (lp = 0; lp < max_page+1; lp+=page_step) {

                 printf("now reading block %d\r",lp);
                 fflush(stdout);

                 if (authorize(SN,lp,PICC_AUTHENT1A) != TAG_OK){
                    errcnt++;
                    fprintf(fmem_str,"%02d: %s\n",lp,"Authentification error");

                    // try to recover (expect impact 4 blocks = 1 sector)
                    find_tag(&CType);
                    select_tag_sn(SN,&SN_len);
                 }
                 else{
                    read_tag_str(lp,str);
                    fprintf(fmem_str,"%02d: %s\n",lp,str);
                }
        }
        fclose(fmem_str);

        if(errcnt == 0 ){
            printf(GRNSTR,"All done. You can remove card.\n");
            sprintf(err_str, "Content read is saved in %s\n",file_str);
            printf(GRNSTR,err_str);
        }
        else {
            sprintf(err_str, "\n%d error(s) during reading.\n", errcnt);
            printf(REDSTR,err_str);
            sprintf(err_str, "Any content read is saved in %s\n",file_str);
            printf(REDSTR,err_str);
        }
        printf(YLWSTR,"Please remove card.\n");
        sleep(5);
    }
    return(status);
}

/* perform action based on card number */

int perform_action()
{
    pid_t child;                    // execute command
    int tmp, i;
                                    // look for match to serial number
    if (find_config_param(sn_str,str,sizeof(str),1)>0)
    {
        child=fork();               // if found : create child
        if (child==0) {
            fclose(stdin);
            freopen("","w",stdout);
            freopen("","w",stderr); // execute command
            execl("/bin/sh","sh","-c",str,NULL);
        } else if (child>0) {       // wait max 1 minute
            i=6000;
            do {
                usleep(10000);
                tmp=wait3(NULL,WNOHANG,NULL);
                i--;
            } while (i>0 && tmp!=child);

            if (tmp!=child) {
                kill(child,SIGKILL);
                wait3(NULL,0,NULL);
                if (debug) {fprintf(stderr,"Killed\n");}
                return(1);
            }else {
                if (debug) {fprintf(stderr,"Exit\n");}
            }
        }else{
            fprintf(stderr,"Can't run child process! (%s %s)\n",sn_str,str);
            return(1);
            }
     }
     else
        printf("No action found in %s for number %s\n",config_file,sn_str);

     return(2);
}

/* wait for card, read card type and serial number */

int get_card_info()
{
    int status;
    int cnt = 0;

    InitRc522();    // needs re-init after each card

    printf(BLUSTR,"Hold your card for the reader ");
    fflush(stdout);

    do
    {
        status = find_tag(&CType);

        if (cnt++ > 3){                 // display keep alive
            cnt = 0;
            printf(BLUSTR,".");
            fflush(stdout);
        }

        if (status == TAG_NOTAG) {     // no card (wait 2 seconds))
            usleep(200000);
            continue;
        }
        else if                        // issue with tag reading ?
        ((status!=TAG_OK)&&(status!=TAG_COLLISION))
            continue;
                                        // read serial number
        status = select_tag_sn(SN,&SN_len);

    } while (status != TAG_OK);

    printf(GRNSTR," card found.\n");
    return(status);

}


int main(int argc, char *argv[]) {

    char    *p,ch;
    int     tmp;
    int     d_write = 0,d_read = 0, action=0, change=0, add_act=0;
    int     option = 0, upd_key=0, prev_loop=0;

    while ((option = getopt(argc,argv,"achksrdpw")) != -1) {
        switch(option) {
            case 'h' : {usage(argv[0]); exit(0);}
                break;
            case 'd' : {debug = 1;printf("Debug mode.\n");}
                break;
            case 'w' : d_write = 1;
                break;
            case 'a' : add_act = 1;
                break;
            case 's' : save_mem = 1;
                break;
            case 'k' : upd_key = 1;
                break;
            case 'r' : d_read = 1;
                break;
            case 'p' : action = 1;
                break;
            case 'c' : change = 1;
                break;
            default  : {usage(argv[0]); exit(1);}
        }
    }

    if (geteuid() != 0){
        printf(REDSTR,"Must be run as root.\n");
        exit(1);
    }
    /* read /etc/rc522.conf */
    if (get_config_file()) exit(1);

    /* set BCM2835 Pins correct */
    if (HW_init(spi_speed,gpio)) close_out(1);

    /* read & set GID and UID from config file */
    if (read_conf_uid()!= 0) close_out(1);


    while (loop > 0){

        if ((loop != prev_loop) && (endless == 0)){
            printf("\nWill stil handle %d cards\n", loop);
            prev_loop = loop;
        }

        /* read a specific card block */
        if (d_read){
            if (read_from_card()) close_out(1);
            else if (endless == 0)    loop--;
        }
        /* write a specific card block */
        else if (d_write){
            if(write_to_card()) close_out(1);
            else if (endless == 0)    loop--;
        }
        /* do action based on info in a specific card block */
        else if (add_act){
            if (addr_action()) close_out(1);
            else if (endless == 0)    loop--;
        }
        /* change access right on a specific card block */
        else if (change){
            if (change_con()) close_out(1);
            else if (endless == 0)    loop--;
        }
        /* update a key on specific sector */
        else if (upd_key){
            if (key_upd()) close_out(1);
            else if (endless == 0)    loop--;
        }
        else {

            // wait for card
            if (get_card_info() != TAG_OK)    continue;

            // determine memory details
            switch (CType) {
                case 0x4400:           // 16 blocks of 8 bytes
                    max_page=0x0f;
                    page_step=4;       // increment to read the card
                    break;
                case 0x0400:           // 64 blocks of 16 bytes / Ul card
                    max_page=0x3f;
                    page_step=1;       // increment to read the card
                    break;
                default:
                    printf(YLWSTR,"Card type not known. Do you want to continue ? ( y/n ) ");
                    scanf("%c",&ch);

                    if ((ch != 'y') || (ch != 'Y')){
                        PcdHalt();
                        close_out(1);
                    }
                    break;
            }
            // count this card
            if (endless == 0)    loop--;

            p=sn_str;                       // create serial string
            *(p++)='[';                     // start with [
            for (tmp=0;tmp<SN_len;tmp++) {  // add serial number
                sprintf(p,"%02x",SN[tmp]);
                p+=2;
            }
            *(p++)=']';                     // close out with ]
            *(p++)=0;

            //for debugging
            if (debug)
                {fprintf(stderr,"Tag: type=%04x SNlen=%d SN=%s\n",CType,SN_len,sn_str);}

            // save memory of card ??
            if (save_mem)   read_card_to_file();

            //find match to serial number string in config file
            else if (action){

                perform_action();
            }

            else
                printf("Tag: type=%04x SNlen=%d SN=%s\n",CType,SN_len,sn_str);
                printf(YLWSTR,"Please remove card\n");
                sleep(5);
            // close / disconnect the card
            PcdHalt();
        }
    }   // loop

    close_out(0);
}
