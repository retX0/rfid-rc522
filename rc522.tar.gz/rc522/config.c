/*
 * config.c
 *
 *  Created on: 05.09.2013
 *      Author: alexs
 */

#include "config.h"

char config_file[255]="/etc/RC522.conf";
FILE *fdconfig=NULL;
char str[255];

// needed for authentication
uint8_t KEYA[6];
uint8_t KEYB[6];
// default authentication values
uint8_t KEYA_def[6]= {0xFF,0XFF,0XFF,0XFF,0XFF,0XFF};
uint8_t KEYB_def[6]= {0xFF,0XFF,0XFF,0XFF,0XFF,0XFF};

void reload_config (int sugnum) {

}
int read_conf_uid() {
    char user[5];
    uid_t uid;
    gid_t gid;

    if (find_config_param("UID=",user,sizeof(user),0)<=0) {

        if  (getuid()<100) {
            printf("UID must be set!\n");
            return -1;
        }
    }else{
        uid=(int)strtol(user,NULL,10);

        if (uid<100) {
            printf("Invalid UID: %s\n",user);
            return -1;
        }
        setuid(uid);
    }
    if (find_config_param("GID=",user,sizeof(user),0)==1) {
        gid=(int)strtol(user,NULL,10);
        setgid(gid);
    }
    return 0;
}
/*
 * Read KeyA or KeyB for a specific sector on a specific card
 * if not found default KeyA | KeyB will be set
 *
 * Format:
 * Header = [xxy{
 *      xx =  Sectornumber (between 00 - 15)
 *       y  =  A or B (whether KEYA or KEYB)
 * card serialnumber (* = applies to all cards, otherwise specific card)
 * seperator = }
 * key (6 bytes seperated by space)
 * Trailer = ]
 * example : [09A{c319eba4}aa bb cc dd ee 09]
 */

int read_conf_key(int addr, int auth_key)
{
    char    s_key[10];          // search key
    char    result[50];         // search result
    char    conv[50];           // needed for conversion
    char    *p;
    int     i, j, tmp;
    int     sector=0;           // sector 0 -15
    int     keyfound=0;         // catch a match
    int     ser[10];            // used during checking


    // set default key
    for (tmp=0; tmp < 6; tmp++)
    {
        if (auth_key == PICC_AUTHENT1A)
            KEYA[tmp] = KEYA_def[tmp];
        else
            KEYB[tmp] = KEYB_def[tmp];
    }

    // determine sector
    tmp = addr;
    while(tmp > 3){
        sector++;
        tmp -= 4;
    }

    // create search key
    p = s_key;
    *(p++) = '[';                   // start with [
    sprintf(p,"%02d",sector);       // add sector
    p += 2;

    if (auth_key == PICC_AUTHENT1A)
        *(p++) = 'A';               // look for keyA
    else
        *(p++) = 'B';               // look for keyB

    *(p++) = '{';                   // add {
    *(p++) = 0;

    // printf("search %s\n",s_key);
    // try to find KEY
    if (find_config_param(s_key,result,sizeof(result), 0 ) > 0)
    {

        // KEY if found
        if (result[0] == '*'){      // for all cards with this address ?
            keyfound = 1;
            conv[0] = '*';          // for potential debug display
            conv[1] = 0x0;
            p = &result[1];         // skip *
        }
        else                        // serial number match
        {
            i=0;
            j=0;

            // convert serial number to hex (max. 10 bytes )
            for (tmp = 0; tmp < 20; tmp++) {

                if (result[tmp] == '}'){        // end serial number

                    if (i != 0) j = SN_len + 1; // 1 nibble boundary ?

                    p = &result[tmp];

                    break;
                }

                conv[i++] = result[tmp];

                if (i == 2) {                   // 2 nibbles ?
                    conv[i] = 0x0;
                    sscanf(conv,"%x", &ser[j++]);
                    i = 0;
                }
            }

            if (j == SN_len) {          // same length?

                // check for match
                for (tmp = 0; tmp < SN_len; tmp++) {
                    if (SN[tmp] != ser[tmp])   break;
                }

                if (tmp == SN_len) keyfound=1;
            }
        }

        if (debug)
            if (keyfound) printf("Match found for KEY, sector %d\n",sector);
            else printf("Using default key for sector %d\n",sector);

        if (keyfound){                  // match found

            if (*(p++) != '}')          // check seperator
                return(1);
                                        // copy key (12 + 5 spaces)
            for (tmp=0; tmp < 20; tmp++){

                if (*(p) == ']'){       // end of KEY ?

                    if (conv[tmp-1] == 0x20)
                        tmp = tmp -1;

                    conv[tmp] = 0x0;
                    break;
                }

                conv[tmp] = *(p++);
            }

            if (tmp == 17)
            {
                if (auth_key == PICC_AUTHENT1A)
                    sscanf(conv,"%x %x %x %x %x %x",&KEYA[0],&KEYA[1],&KEYA[2],&KEYA[3],&KEYA[4],&KEYA[5]);
                else
                    sscanf(conv,"%x %x %x %x %x %x",&KEYB[0],&KEYB[1],&KEYB[2],&KEYB[3],&KEYB[4],&KEYB[5]);
            }
            else
            {
                printf("Invalid key: not correct length %d => %s.\n",tmp,conv);
                return(1);
            }
        }


        if (debug){
            if (auth_key == PICC_AUTHENT1A) printf("Key A set to: ");
            else printf("Key B set to: ");
            for (tmp=0; tmp < 6; tmp++)
                printf("0x%x ",KEYA[tmp]);
            printf("\n");
        }
    }
    else
       if (debug) printf("Using default authentication key.\n");

    return(0);
}


int open_config_file(char * conffile) {
    if (fdconfig==NULL) {
        if (access(conffile,W_OK)!=0) return -1;
        if ((fdconfig=fopen(conffile,"r+"))==NULL) return -1;
    }
    return 0;
}

void close_config_file() {
    fclose(fdconfig);
}

int find_config_param(char * param_name, char * param_val, int val_len, int log) {
    int param_found=0;
    char * pstr;

    if (fseek(fdconfig, 0L, SEEK_SET)!=0) return -1;

    while (fgets(str,sizeof(str)-1,fdconfig)!= NULL) {

        if ((pstr=strchr(str,'#'))!= NULL) *pstr=0;

        if ((pstr=strstr(str,param_name))!= NULL) {
            param_found=1;
            //if (log) syslog(LOG_DAEMON|LOG_INFO,"Found param. %s",str);
            pstr+=strlen(param_name);
            while (isspace(*pstr)) pstr++;
            while (isspace(pstr[strlen(pstr)-1])) pstr[strlen(pstr)-1]=0;
            strncpy(param_val,pstr,val_len);
#if DEBUG==1
            printf("Debug:%s\n",param_val);
#endif
            break;
        }
    }
    return param_found;
}

/* Add null terminate string as line to end of config file, newline will be add */

int add_to_config(char *buf){

    int status = 0;

    // go to end of file
    if (fseek(fdconfig, 0L, SEEK_END)!= 0) return (1);

    // write buffer
    status = fputs(buf,fdconfig);
    if (status == EOF)  return(1);

    // write newline to buffer
    status = fputs("\n",fdconfig);
    if (status == EOF)  return(1);

    // flush
    status = fflush(fdconfig);

    return(0);
}
