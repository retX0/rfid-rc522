/*
 * rfid.c
 *
 *  Created on: 06.09.2013
 *      Author: alexs
 */
#include "rfid.h"



uint8_t buff[MAXRLEN];


tag_stat find_tag(uint16_t * card_type) {
    tag_stat tmp;

    /* perform Transceive request to obtain card info
     * IDLE will follow POR (power on request) and communication failure
     * REQALL => all cards in the initial state will respond
     * REQIDL => cards that were NOT set into halt state will respond
     *
     * */

    if ((tmp=PcdRequest(PICC_REQIDL,buff))==TAG_OK) {

    //if ((tmp=PcdRequest(PICC_REQALL,buff))==TAG_OK) {
        *card_type=(int)(buff[0]<<8|buff[1]);
    }

    return tmp;
}
/*
 * 0x93 = cascade level 1   return UID0-UID3 or CT+UID0-UID2
 * 0x95 = cascade level 2   retrunUID3-UID6 or CT+UID3-UID5
 * 0x97 = cascade level 3
 *
 * 0x92 = 0x93 + switch to f/64
 * 0x94 = 0x95 + switch to f/32
 * 0x98 = 0x97 + switch to f/16
 */
tag_stat select_tag_sn(uint8_t * sn, uint8_t * len){

    int j;

    /* get basic UID from card */
    if (PcdAnticoll(PICC_ANTICOLL1,buff)!=TAG_OK) {return TAG_ERR;}

    /* select the card */
    if (PcdSelect(PICC_ANTICOLL1,buff)!=TAG_OK) {return TAG_ERR;}

    if (buff[0]== 0x88) {       // 0x88 is CT (means next level to cascade)

        memcpy(sn,&buff[1],3);
        // 0x95 => get cascade level 2 and select
        if (PcdAnticoll(PICC_ANTICOLL2,buff)!=TAG_OK) {
            return TAG_ERR;}

        if (PcdSelect(PICC_ANTICOLL2,buff)!=TAG_OK) {return TAG_ERR;}

        if (buff[0]==0x88) {
            memcpy(sn+3,&buff[1],3);
            // 0x97 => get even more extended serial number (RATS)
            if (PcdAnticoll(PICC_ANTICOLL3,buff)!=TAG_OK) {
                return TAG_ERR;}

            if (PcdSelect(PICC_ANTICOLL3,buff)!=TAG_OK) {return TAG_ERR;}

            memcpy(sn+6,buff,4);
            *len=10;        // 10 byte UID ( triple size UID) PSS
        }
        else{
            memcpy(sn+3,buff,4);
            /* 7 byte UID (double size) Mifare Ultralight, Ultralight C, Desfire
             * Desfire EV1 and Mifare Plus (7 B UID)
             */
            *len=7;         // 7 byte Unique ID (double size UID)
        }
    }else{
        memcpy(sn,&buff[0],4);
        /* 4 byte non-unique ID (single byte UID) - discontinued end 2010
         * were set at manufacturing..
         * used on Mifare Classic 1K, Mifare Classic 4K and some Mifare Plus versions
         */
        *len=4;
    }
    return TAG_OK;
}
/* read a block and return value as string */

tag_stat read_tag_str(uint8_t addr, char * str) {
    tag_stat tmp;
    char *p;
    uint8_t i;

    uint8_t buff[MAXRLEN];

    tmp=PcdRead(addr,buff);
    p=str;
    // printf("read return status %x\n",tmp);

    if (tmp==TAG_OK) {
        for (i=0;i<16;i++) {
            sprintf(p,"%02x",(char)buff[i]);
            p+=2;
        }

    }else if (tmp==TAG_ERRCRC){
        sprintf(p,"CRC Error");

    }else{
        sprintf(p,"Unknown error");
    }
    return tmp;
}


