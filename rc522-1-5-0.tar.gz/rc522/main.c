/*
 * main.c
 *
 *  Created on: 14.08.2013
 *      authorizer: alexs
 *
 * version 1.0 / paulvha / March 2016
 * Based on the original RC522.c package, added functionality to
 * make it work and work easy.
 *
 * Original package could already:
 *  Execute a program based on the card serial number
 *  Display the card type and serial number
 *  Reading to file as included, but missed authentication to work
 *
 * It now can:
 *  Read a specific block and display content
 *  Read ALL blocks into a file (added the missing authentication)
 *  Write on specific block, specific data (+ check security)
 *  Add ability to set access bits on different blocks
 *  Add ability to change the KEYA or KEYB per sector/card and add to config file
 *  Additional command line options to control
 *
 *  + streamlined to program, added source code comments
 *
 * version 1.1 / paulvha / April 2016
 *  fix in read_conf_key (config.c) as sscanf expects int * and not uint8_t (char *) for %x
 *  newer compilers are checking more strict.
 *
 * version 1.11 / paulvha / April 2016
 *  fixed number of issues as newer compilers are checking more strict.
 *
 * version 1.12 / paulvha / April 2016
 *  fixed issue with checking on NotEndless loop. Now checking for zero instead of negative
 * 
 * version 1.50 / paulvh / July 2017
 * Fixed number of bugs and code clean-up.
 */

char VERSION[] = "1.50";

#include "main.h"
#include "rc522.h"
#include "config.h"

uint8_t debug=0;
uint8_t use_gpio=0;         // was valid GPIO for reset ?
uint8_t gpio=255;           // GPIO for reset

uint32_t spi_speed = 1000000L; // speed for SP (4 < >125) overruled by config file value

char    fmem_path[255];     // to hold the directory for memory save (from config file)
char    save_mem=0;         // trigger (or disable if issues in config file) to save card info

uint8_t loop = 10, NotEndless = 1; // main loop

// card information (globally used)
uint8_t SN[10];             // serial number of card
uint16_t CType=0;           // card type/ ATAQ response

uint8_t SN_len=0;           // length of serial number ( 4 / 7 / 10)
char    sn_str[23];         // to hold [serial]

int     max_page=0x3f;      // # of pages on card
uint8_t page_step=0;        // increment to read the card

// disable color output (if set)
int		NoColor = 0;


/*********************************************************************************************************
** Function name:           p_printf
** Descriptions:            display debug message
**
** @param format : debug message to display and optional arguments
**                 same as printf
** @param level :  1 = RED, 2 = GREEN, 3 = YELLOW 4 = BLUE 5 = WHITE
** 
** if NOCOLOR was set, output is WHITE.
*********************************************************************************************************/

void p_printf (int level, char *format, ...)
{
    char	*col;
    int		coll=level;
    va_list arg;
    
    //allocate memory
    col = malloc(strlen(format) + 20);
    
    if (NoColor) coll = WHITE;
				
    switch(coll)
    {
		case RED:
			sprintf(col,REDSTR, format);
			break;
		case GREEN:
			sprintf(col,GRNSTR, format);
			break;		
		case YELLOW:
			sprintf(col,YLWSTR, format);
			break;		
		case BLUE:
			sprintf(col,BLUSTR, format);
			break;
		default:
			sprintf(col,"%s",format);
	}
    // special version
   	va_start (arg, format);
	vfprintf (stdout, col, arg);
	va_end (arg);

	fflush(stdout);

    // release memory
    free(col);
}


/* perform init BCM and GPIO */

uint8_t HW_init(uint32_t spi_speed, uint8_t gpio) {
    uint16_t sp;

    sp=(uint16_t)(250000L/spi_speed);

    if (!bcm2835_init()) {
        syslog(LOG_DAEMON|LOG_ERR,"Can't init bcm2835!\n");
        return 1;
    }
    
    // HARD reset RC522 (only with valid gpio from config)
    if (use_gpio) 
    {         
        bcm2835_gpio_fsel(gpio, BCM2835_GPIO_FSEL_OUTP);

        // NRSTPD = low is OUT/ power down (PD)]
        bcm2835_gpio_write(gpio, LOW);
        bcm2835_delay(500);

        // NRSTPD = positve edge is reset + run
        bcm2835_gpio_write(gpio, HIGH);
        bcm2835_delay(500);
    }
    else
    {
		p_printf(RED,"GPIO in config file must be lower than 28\n");
		exit(1);
	}

    bcm2835_spi_begin();    // set pins 19, 21, 23, 24, 26
    
    // most significant bit is sent first
    bcm2835_spi_setBitOrder(BCM2835_SPI_BIT_ORDER_MSBFIRST);
    
    bcm2835_spi_setDataMode(BCM2835_SPI_MODE0);                   // The default
    bcm2835_spi_setClockDivider(sp);                              // The default
    bcm2835_spi_chipSelect(BCM2835_SPI_CS0);                      // The default
    bcm2835_spi_setChipSelectPolarity(BCM2835_SPI_CS0, LOW);      // the default
    return 0;
}

/* restore and terminate program */
void close_out(int ex_code)
{
    if (use_gpio) bcm2835_gpio_write(gpio, LOW); // set reset
    bcm2835_spi_end();
    bcm2835_close();
    close_config_file();
    exit(ex_code);
}

void usage(char * str) {
    p_printf(YELLOW, "Usage:\n%s [options]:           (version %s)\n"
    "\t  -d  enable debug mode\n"
    "\t  -n  No color in messages\n"
    "\t  -w  write to card block\n"
    "\t  -r  read a card block\n"
    "\t  -s  save content all card blocks in a file\n"
    "\t  -p  perform action on card number (specified in configuration file)\n"
    "\t  -c  change access rights for specific block\n"
    "\t  -a  perform action based on content specific block\n"
    "\t  -k  Change authentication key on a specific sector\n"
    ,str,VERSION);
}

/* calculate sector number based on block */
int calc_sector_number(int block)
{
	int	tmp = block;
	int sct_num=0;
	
	tmp = block;
	
	while(tmp > 3){
		sct_num++;
		tmp -= 4;
	}

	return(sct_num);
}

// get single digital number
int	get_number()
{
	int 	num;
	char 	ch;
	
	scanf("%d", &num);
	
    // flush any input pending
    while ((ch=getchar()) != '\n' && ch != EOF);
    
    return(num);
}

// get single (uppercase) character
char	get_charc()
{
	char 	charc, ch;
	
	scanf("%c", &charc);
	
    // flush any input pending
    while ((ch=getchar()) != '\n' && ch != EOF);
    
    return(toupper(charc));
}

// get string (it is assumed the buffer is large enough to hold entry)
void	get_str(char * buf)
{
	char 	ch;
	
	scanf("%s", buf);
	
    // flush any input pending
    while ((ch=getchar()) != '\n' && ch != EOF);
}

/* determine block trailer */
int calc_block_trailer(int addr)
{
	int tmp = addr;
    int t_addr = 3;

    while (tmp > 3)             
    {
          t_addr += 4;
          tmp -= 4;
    }
    
    return (t_addr);
}

/* update key on specific sector */
int key_upd(){
    int             addr = -1, t_addr;
    unsigned char   ch, key = 'c';
    int             i = 0 , j, tmp;
    int             sct_num = -1;
    unsigned char  	buff[50];
    char            buf[50], *p;
    int             new_key[6];

    do
    {
        p_printf (YELLOW,"Do you want to provide s = sector or b = block number for key-update (e = exit) ");
        ch = get_charc();
		
		// check response
        if (ch == 'E')  close_out(0);
        else if (ch == 'S') i = 1;
        else if (ch == 'B') i = 2;
        else p_printf(RED,"Invalid entry  's' or 'b'\n");

    } while (i == 0);

    if (i == 2)
    {
        do    // get valid block
        {
            p_printf (YELLOW,"Provide block where to update sector key. Max %d (99 = return) : ", max_page);
            addr=get_number();

			if (addr == 99)  return(0);
            
            if (addr > max_page) {
                p_printf (RED,"Block number is to high %2d. Maximum %d\n",addr, max_page);
                addr = -1;
            }
            else if (addr < 0){
                p_printf(RED,"Block can't be below 0.\n");
                addr = -1;
            }

        } while (addr == -1);

        // determine sct_num
        sct_num=calc_sector_number(addr);
    }
    else
    {
        do    // get valid sector
        {
            p_printf (YELLOW,"Please provide the sector (0 - 15) to update key. (99 = return) : ");
            sct_num=get_number();

            if (sct_num == 99)  return(0);

            if ((sct_num < 0) || (sct_num > 15))
            {
                p_printf(RED,"Invalid sector-number. Please try again.\n");
                sct_num = -1;
            }

        } while (sct_num == -1);
        
        addr = sct_num * 4;
     }

    do    // get key A or B
    {
        p_printf (YELLOW,"Which key do you want to update A = KEYA or B = KEYB (E = return) : ");
        key=get_charc();

        if (key =='E') return(0);

        if ((key != 'A') &&  (key != 'B'))
            p_printf(RED,"Invalid key. Please try again.\n");

    } while ((key != 'A') &&  (key != 'B'));

    // get the new key
    for (i=0 ; i < 6; i++)
    {
        do
        {
            p_printf(YELLOW,"Provide authentication byte %2d of 6 : 0x",i+1);

            tmp = scanf("%x", &new_key[i]);

            if (tmp == 0) p_printf(RED,"Invalid entry. Try again.\n");

            // flush any input pending
            while ((ch=getchar()) != '\n' && ch != EOF);

        } while (tmp == 0);

    }
    
    // get confirmation
    i = 0;
    j = sct_num;
    while (j-- > 0) i += 4;
    
    p_printf(RED,"******** IMPORTANT TO DOUBLE CHECK ***************\n"
    "You are about to make a change to KEY%c:\n"
    "Sector %d, with the block range of %d - %d\n",key, sct_num, i,i+3);


    for (i=0 ; i < 6; i++)  p_printf(YELLOW,"0x%02x ",new_key[i]);
    
    i=0;
    do
    {
        p_printf(YELLOW,"\nIs the correct (yes, no or exit) ? ");
        get_str(buf);

        if (strcasecmp(buf,"no") == 0)
            return(0);

        else if (strcasecmp(buf,"yes") == 0)
             i=1;

        else if (strcasecmp(buf,"exit") == 0)
             close_out(0);

        else
            p_printf(RED,"Invalid answer. Please type 'yes' or 'no' or 'exit' \n");

    }   while (i == 0);

    // wait for card
    if (get_card_info() != TAG_OK)    return(1);

    p_printf(RED,
    "**********************************************\n"
    "  DO NOT REMOVE YOUR CARD FROM THE READER !!\n"
    "**********************************************\n\n");

    // check block fit
    if (addr > max_page) {
        p_printf(RED,"This card has only %d blocks. Can not read from %d.\n",max_page, addr);
        PcdHalt();
        return(0);
    }
	
    // determine access rights : access trailer
	t_addr = calc_block_trailer(addr);

    if (authorize(SN, t_addr,PICC_AUTHENT1A) != TAG_OK) return(1);

    if (PcdRead(t_addr,buff) != TAG_OK){       // read trailer
        p_printf(RED,"Error during reading trailer. %d\n",addr);
        PcdHalt();
        return(1);
    }

    /* as we authenticate with ONE key and if we do NOT want to update the other, we have
     * to get the current valid other key for this sector first to write back.
     * 
     * Depending on the access BITS, KEYA might be able to read KEYB, but that is not a given. 
     * 
     * Under NO condition the KEYA can be read with the Trailer (always zero) 
     * just to be sure we try to obtain KEYB (either default or as stored in the config file
     * 	
     */

    if (key == 'A'){
        
        if (read_conf_key(t_addr,PICC_AUTHENT1B) != 0){
            p_printf(RED,"Error during obtaining current KEYB for sector %d\n",sct_num);
            return(1);
        }
    }

    // add new key
    for (i = 0; i< sizeof(KEYA); i++)
    {
		if (key == 'A') 
		{
			buff[i] = new_key[i];
			buff[i+10] = KEYB[i];
		
		}
		else
		{
			buff[i] = KEYA[i];			// we have to write KEYA (always reads as zero's)
			buff[i+10] = new_key[i];
		}
	}
	
    if (debug)
    {
        p_printf(YELLOW, "New trailer to be written : ");
        for (i = 0;i<16;i++)  p_printf(YELLOW,"%02x",buff[i]);
        p_printf(WHITE,"\n");
    }

    // update trailer
    if (PcdWrite(t_addr, buff) != TAG_OK)
    {
        p_printf(RED,"Error during update trailer.\n");
        PcdHalt();
        return(1);
    }

    // read back to double check
    if (debug)
    {   
		if (PcdRead(t_addr,buff) == TAG_OK)
			p_printf(YELLOW, "Trailer %d has been read and has the following content %s\n",t_addr, buff);
		else
			p_printf(RED,"Error during reading trailer after write\n");
    }

    // close / disconnect the card
    PcdHalt();
    
    p_printf(GREEN,
    "KEY%c has been updated. You can remove the card\n"
	"Make sure to write down the new code KEY%c : ",key, key);

    for (i=0 ; i < 6; i++)  p_printf(YELLOW,"%2x ",new_key[i]);
    
    p_printf(RED,"\nOtherwise access to this sector is lost and can not be recovered\n");

	// try to add to bottom of configuration file
	
    p=buf;

    // create search key
    *(p++) = '#';               // set as comment
    *(p++) = '[';               // start with [
    sprintf(p,"%02d",sct_num);  // add sector
    p += 2;
    *(p++) = key;               // add key
    *(p++) = '{';               // add {

    // serial number
    for(i = 0; i < SN_len;i++)
    {
        sprintf(p,"%02x",SN[i]);
        p += 2;
    }
    *(p++) = '}';               // add separator

    for(i = 0; i < 6;i++)       // add new key
    {
        sprintf(p,"%02x ",new_key[i]);
        p += 3;
    }
    p--;
    *(p++) = ']';               // add trailer
    *(p++) = 0;

    if (add_to_config(buf)){
        p_printf(RED,"Error during adding to config file %s: %s\n",config_file, buf);
       
        p_printf(RED,"Write down this code and add manually (without leading #)\n");
        return(1);
    }

    p_printf(GREEN,"An entry %s has been added to the config file %s\n", buf, config_file);
    p_printf(YELLOW,"It is the last line and you need to remove the '#' manually to make it valid.\n");
    return(0);
}
/* Get authorization to access memory
 * snr = buffer with serial number
 * block = block to get access to
 * auth_key = use KEYA (PICC_AUTHENT1A) or KEYB (PICC_AUTHENT1B)
 *
 *
 * */

int authorize(uint8_t *pSnr, int block, int auth_key)
{
    int status=0, i;
    uint8_t *p;
    int get_key = 1, sct_num=0;

	// need to prevent repeat authentication key check
	static int prev_sct_num=0xff;
	static int prev_auth_key=0xff;
	static uint8_t prev_sn[10];

    // determine sct_num
    i = block;
    while(i > 3){
        sct_num++;
        i -= 4;
    }
    // do we need to retrieve the code again ?
    if (sct_num == prev_sct_num)            // same block before ?
    {
        if (auth_key == prev_auth_key)    	// for same key (A or B) ?
        {
            
            for (i=0; i<SN_len; i++)
            {
                if (prev_sn[i] != pSnr[i])
                        break;
			}
			
            if (i == SN_len) get_key = 0;
        }
    }
    //printf("%s :get key %d, sct_num %d, block %d\n",__func__, get_key,sct_num,block);
    
    if (get_key)
    {
            status = read_conf_key(block, auth_key);

            if (status) {
                p_printf(RED,"Issue with obtaining authentication key !!!! \n");
                return(status);
            }
            else
            {
                prev_sct_num = sct_num;
                prev_auth_key = auth_key;
                p=pSnr;
                for (i=0;i <SN_len;i++)
                    prev_sn[i]= *(p++);
            }
    }

    if (auth_key == PICC_AUTHENT1A)
        status = PcdAuthState(PICC_AUTHENT1A,block,KEYA,pSnr);

    else
        status = PcdAuthState(PICC_AUTHENT1B,block,KEYB,pSnr);

    if (status != TAG_OK)
    {
        p_printf(RED,"Authentification error !!!! \n");
        prev_auth_key = 0xff;      // force recapture of key next time
    }
    
    return(status);
}

/* read the config file information */

int get_config_file()
{
    char    str[255]; 
    
    if (open_config_file(config_file)!=0) {
        fprintf(stderr,"Can't open config file! (need read/write permissions)\n");
        return(1);
    }
    
    if (find_config_param("GPIO=",str,sizeof(str)-1,1)==1) 
    {
        gpio=(uint8_t)strtol(str,NULL,10);

        if (gpio < 28)  use_gpio=1;
    }

    if (find_config_param("SPI_SPEED=",str,sizeof(str)-1,1)==1) {
        spi_speed = (uint32_t) strtoul(str,NULL,10);
        if (spi_speed > 125000L) spi_speed=125000L;
        if (spi_speed < 4) spi_speed=4;
    }

    if (find_config_param("NEW_TAG_PATH=",fmem_path,sizeof(fmem_path)-1,0)) 
    {
        if (fmem_path[strlen(fmem_path)-1]!='/')
            sprintf(&fmem_path[strlen(fmem_path)],"/");

        if (strlen(fmem_path)>=240) {
            p_printf(RED,"Too long path for tag dump files!\n can not save to file");
            save_mem = 0;
            return(1);
         }
    }
    else
        save_mem = 0;

    if (find_config_param("LOOP=",str,sizeof(str)-1,1)==1) {
        loop=(uint8_t)strtol(str,NULL,10);

        if (loop == 0)
        {      
			loop = 1;               // 1.12 check for zero !
			NotEndless = 0;         // Endless
		}
    }
    
    return(0);
}

/* wait and read card permission for block */
int get_card_permission(int addr)
{
    int             t_addr, i;
    unsigned char   ch;
    uint8_t         buff[100];

    // wait for card
    if (get_card_info() != TAG_OK)    return(-1);

    // check block fit
    if (addr > max_page) {
        p_printf(RED,"This card has only %d blocks. Can not access %d.\n",max_page, addr);
        PcdHalt();
        return(-1);
    }

    // determine access rights : access trailer
	t_addr = calc_block_trailer(addr);

	// authorize access and read trailer information
    if (authorize(SN, t_addr,PICC_AUTHENT1A) != TAG_OK) return(-1);

    if (PcdRead(t_addr,buff) != TAG_OK){       // read trailer
        p_printf(RED,"Error during reader trailer %d\n",addr);
        return(-1);
    }

    i = 3 -(t_addr-addr);        // offset  -------------- access bits --------------------
                                // C1                      C2                           C3
    if (i == 0)         ch = (buff[7] & B0B7C1) >> 4 | (buff[8] & B0B8C2) << 1 | (buff[8] & B0B8C3) >> 2;
    else if (i == 1)    ch = (buff[7] & B1B7C1) >> 5 | (buff[8] & B1B8C2) << 0 | (buff[8] & B1B8C3) >> 3;
    else if (i == 2)    ch = (buff[7] & B2B7C1) >> 6 | (buff[8] & B2B8C2) >> 1 | (buff[8] & B2B8C3) >> 4;
    else if (i == 3)    ch = (buff[7] & TB7C1) >> 7  | (buff[8] & TB8C2) >> 2  | (buff[8] & TB8C3) >> 5;
    else {
        p_printf(RED,"Issue with analysing trailer.\n");
        PcdHalt();
        return(-1);
    }
    
    return(ch);
}

/* perform action based on content specific block
 * action is defined in rc522.conf as [@code] */

int addr_action(){

    int             addr = -1;
    unsigned char   ch;
    int             tmp;
    uint8_t         buff[50];
    char            *p;


    do    // get valid block
    {
        p_printf (YELLOW,"Please provide the block number to read action-code. (Max %d) : ", max_page);
        addr =get_number();

        if (addr == 99)  close_out(0);

        if (addr > max_page) {
            p_printf(RED,"Block number is to high %2d. Maximum %d.\n",addr, max_page);
            addr = -1;

        }
        else if (addr < 0){
            p_printf(RED,"Block can't be below 0.\n");
            addr = -1;
        }

        else if ((addr == 3) || (! ((addr-3) % 4))){
            p_printf (RED,"Can not use a trailer location.\n");
            addr = -1;
        }

    } while (addr == -1);

    if ((ch = get_card_permission(addr)) < 0) return(1);

    /* As KEYA is used for access, bit 1 should not be set, unless the value is 1
     * value 0 = default (With KEYA you can to everything except read KEYA)
     * 
     * As it was able to authenticate with KEYA, it might be able to read with KEYB instead (access == 0x3)
     * 
     * see MF1IC520_rev5_3.pdf card description.
     */

    if ((ch & 0x01) && (ch != 1) )
    {
		// use KEYB to read instead ?
		if (ch == 0x3 || ch == 0x5)
		{
			// access memory block with KEYB
			if (authorize(SN, addr,PICC_AUTHENT1B) != TAG_OK)
			{
				PcdHalt();
				return(1);
			}			
		}
		else
		{	
	        p_printf(RED,"Block %d has no read permission. (code: %x) \n", addr,ch);
	        PcdHalt();
	        return(1);
		}
	}
	else
	{
        // access memory block with KEYA
		if (authorize(SN, addr,PICC_AUTHENT1A) != TAG_OK)
		{
			PcdHalt();
			return(1);
		}
	}
	
    // read block
    if (read_tag_str(addr,buff) != TAG_OK)
    {
        p_printf(RED,"Error during reading %d\n",addr);
        PcdHalt();
        return(1);
    }

    PcdHalt();

    // create command string
    p=sn_str;
    *(p++)='[';                     // start with [
    *(p++)='@';                     // add @ to make distinction to sen.
    for (tmp=0;tmp<16;tmp++) {      // add block content

       if (buff[tmp] == '0')       // value must be more then 0
            continue;

       *(p++)=buff[tmp];
    }
    *(p++)=']';                     // close out with ]
    *(p++)=0;

    if (debug){
        p_printf(YELLOW, "\nBlock : %d has the following content %s.\n",addr,buff);
        p_printf(YELLOW, "\nCommand string is %s.\n",sn_str);
    }

    if (strlen(sn_str) < 3)
    {
        p_printf(RED,"Not enough action-code characters on block %s.\n",sn_str);
        return(1);
    }
    
    // now search and execute command
    return(perform_action());
}
/* display access permission) */

int disp_access_perm(int access, uint8_t *buff)
{
	int	tmp;
								// offset  -------------- access bits --------------------
                                 // C1                      C2                           C3
    if (access == 0)         tmp = (buff[7] & B0B7C1) >> 4 | (buff[8] & B0B8C2) << 1 | (buff[8] & B0B8C3) >> 2;
    else if (access == 1)    tmp = (buff[7] & B1B7C1) >> 5 | (buff[8] & B1B8C2)      | (buff[8] & B1B8C3) >> 3;
    else if (access == 2)    tmp = (buff[7] & B2B7C1) >> 6 | (buff[8] & B2B8C2) >> 1 | (buff[8] & B2B8C3) >> 4;
    else 
    {
        p_printf(RED,"Issue with analysing trailer.\n");
        PcdHalt();
        return(1);
    }

    p_printf (GREEN,"\nCurrent access permission for this block:\n ");
    p_printf (YELLOW,"\tread\twrite\tincrement\tdecrement,\n\t\t\t\t\ttransfer,\n\t\t\t\t\trestore\n");
    if (tmp == 0){
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
        p_printf(YELLOW,"| 0.\tkeyA|B\tkeyA|B\tkeyA|B\t\tkeyA|B\t   (transport configuration)\n");
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
    } else
        p_printf(WHITE,"  0.\tkeyA|B\tkeyA|B\tkeyA|B\t\tkeyA|B\t(transport configuration)\n");

    if (tmp == 1){
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
        p_printf(YELLOW,"| 1.\tkeyA|B\tnever\tnever\t\tDecrement\t(value block)\n");
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
    } else
        p_printf(WHITE,"  1.\tkeyA|B\tnever\tnever\t\tDecrement\t(value block)\n");

    if (tmp == 2){
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
        p_printf(YELLOW,"| 2.\tkeyA|B\tnever\tnever\t\tnever\t\t(read/write block)\n");
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
    } else
        p_printf(WHITE,"  2.\tkeyA|B\tnever\tnever\t\tnever\t\t(read/write block)\n");

    if (tmp == 3){
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
        p_printf(YELLOW,"| 3.\tkeyB\tkeyB\tnever\t\tnever\t\t(read/write block)\n");
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
    } else
        p_printf(WHITE,"  3.\tkeyB\tkeyB\tnever\t\tnever\t\t(read/write block)\n");

    if (tmp == 4){
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
        p_printf(YELLOW,"| 4.\tkeyA|B\tnever\tnever\t\tnever\t\t(read/write block)\n");
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
    } else
        p_printf(WHITE,"  4.\tkeyA|B\tnever\tnever\t\tnever\t\t(read/write block)\n");

     if (tmp == 5){
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
        p_printf(YELLOW,"| 5.\tkeyB\tnever\tnever\t\tnever\t\t(read/write block)\n");
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
    } else
        p_printf(WHITE,"  5.\tkeyB\tnever\tnever\t\tnever\t\t(read/write block)\n");

     if (tmp == 6){
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
        p_printf(YELLOW,"| 6.\tRecharge only with KeyB \t\t\t\t(value block)\n");
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
    } else
        p_printf(WHITE,"  6.\t\tRecharge on with KeyB \t\t\t(value block)\n");

     if (tmp == 7){
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
        p_printf(YELLOW,"| 7.\tnever\tnever\tnever\t\tnever\t\t(read/write block)\n");
        p_printf(WHITE,"----------------------------------------------------------------------------\n");
    } else
        p_printf(WHITE,"  7.\tnever\tnever\tnever\t\tnever\t\t(read/write block)\n");

	return(0);
}

/* change access conditions for a specific block from the card */

int change_con() {

    int             addr = -1, t_addr,i;
    unsigned char   ch;
    uint8_t         buff[100];

    do    // get valid block
    {
        p_printf (YELLOW,"Please provide the block to update access rights. (Max %d) : ", max_page);
        addr = get_number();

        if (addr == 99)  close_out(0);

        if (addr > max_page) {
            p_printf(RED,"Block number is to high %2d. Maximum %d\n",addr, max_page);
            addr = -1;

        }
        else if (addr < 0){
            p_printf(RED,"Block can't be below 0.\n");
            addr = -1;
        }

        else if ((addr == 3) || (! ((addr-3) % 4))){
            p_printf (RED,"Can not change access to trailer.\n");
            addr = -1;
        }

    } while (addr == -1);

    // wait for card
    if (get_card_info() != TAG_OK)    return(1);

    p_printf(RED,
    "**********************************************\n"
    "  DO NOT REMOVE YOUR CARD FROM THE READER !!\n"
    "**********************************************\n\n");

    // check block fit
    if (addr > max_page) 
    {
        p_printf(RED,"This card has only %d blocks. Can not read from %d.\n",max_page, addr);
        PcdHalt();
        return(0);
    }

    // determine access rights : access trailer
	t_addr = calc_block_trailer(addr);

    if (authorize(SN, t_addr,PICC_AUTHENT1A) != TAG_OK) return(1);

    if (PcdRead(t_addr,buff) != TAG_OK)
    {       // read trailer
        p_printf(RED,"Error during reader trailer %d\n",addr);
        return(1);
    }

	i = 3 -(t_addr-addr);
	
	/* display access permission */
	if (disp_access_perm(3 -(t_addr-addr), buff)) return(1);
    
    ch = '8';
    do          // Ask new access right
    {
        p_printf (YELLOW,"\nDo you want to change ?\nEnter 'n' for NO change or choose number of access right wanted. ");
        ch =get_charc();

        if ((ch == 'n') || (ch == 'N')){
            PcdHalt();
            p_printf(GREEN,"Abort update. You can remove the card\n");
            return(0);
        }

        if ((ch < '0') || (ch > '7')){
            p_printf (RED,"Invalid entry. Try again. %d\n", ch);
            ch = '8';
        }
    }  while (ch == '8');

    //p_printf(WHITE,"Before Byte 7: %x Byte 8 %x\n", buff[7], buff[8]);

    switch(ch){     // update Byte 7 & 8
            case 0x30:
                if (i == 0) {
                    buff[7] = buff[7] & ~B0B7C1;
                    buff[8] = buff[8] & ~B0B8C2;
                    buff[8] = buff[8] & ~B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] & ~B1B7C1;
                    buff[8] = buff[8] & ~B1B8C2;
                    buff[8] = buff[8] & ~B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] & ~B2B7C1;
                    buff[8] = buff[8] & ~B2B8C2;
                    buff[8] = buff[8] & ~B2B8C3;
                }
                break;
            case 0x31:
                if (i == 0) {
                    buff[7] = buff[7] | B0B7C1;
                    buff[8] = buff[8] & ~B0B8C2;
                    buff[8] = buff[8] & ~B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] | B1B7C1;
                    buff[8] = buff[8] & ~B1B8C2;
                    buff[8] = buff[8] & ~B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] | B2B7C1;
                    buff[8] = buff[8] & ~B2B8C2;
                    buff[8] = buff[8] & ~B2B8C3;
                }
                break;
            case 0x32:
                if (i == 0) {
                    buff[7] = buff[7] & ~B0B7C1;
                    buff[8] = buff[8] | B0B8C2;
                    buff[8] = buff[8] & ~B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] & ~B1B7C1;
                    buff[8] = buff[8] | B1B8C2;
                    buff[8] = buff[8] & ~B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] & ~B2B7C1;
                    buff[8] = buff[8] | B2B8C2;
                    buff[8] = buff[8] & ~B2B8C3;
                }

                break;
            case 0x33:
                            if (i == 0) {
                    buff[7] = buff[7] | B0B7C1;
                    buff[8] = buff[8] | B0B8C2;
                    buff[8] = buff[8] & ~B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] | B1B7C1;
                    buff[8] = buff[8] | B1B8C2;
                    buff[8] = buff[8] & ~B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] | B2B7C1;
                    buff[8] = buff[8] | B2B8C2;
                    buff[8] = buff[8] & ~B2B8C3;
                }
                break;
            case 0x34:
                if (i == 0) {
                    buff[7] = buff[7] & ~B0B7C1;
                    buff[8] = buff[8] & ~B0B8C2;
                    buff[8] = buff[8] | B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] & ~B1B7C1;
                    buff[8] = buff[8] & ~B1B8C2;
                    buff[8] = buff[8] | B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] & ~B2B7C1;
                    buff[8] = buff[8] & ~B2B8C2;
                    buff[8] = buff[8] | B2B8C3;
                }
                break;
            case 0x35:
                if (i == 0) {
                    buff[7] = buff[7] | B0B7C1;
                    buff[8] = buff[8] & ~B0B8C2;
                    buff[8] = buff[8] | B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] | B1B7C1;
                    buff[8] = buff[8] & ~B1B8C2;
                    buff[8] = buff[8] | B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] | B2B7C1;
                    buff[8] = buff[8] & ~B2B8C2;
                    buff[8] = buff[8] | B2B8C3;
                }
                break;
            case 0x36:
                if (i == 0) {
                    buff[7] = buff[7] & ~B0B7C1;
                    buff[8] = buff[8] | B0B8C2;
                    buff[8] = buff[8] | B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] & ~B1B7C1;
                    buff[8] = buff[8] | B1B8C2;
                    buff[8] = buff[8] | B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] & ~B2B7C1;
                    buff[8] = buff[8] | B2B8C2;
                    buff[8] = buff[8] | B2B8C3;
                }
                break;
            case 0x37:
                if (i == 0) {
                    buff[7] = buff[7] | B0B7C1;
                    buff[8] = buff[8] | B0B8C2;
                    buff[8] = buff[8] | B0B8C3;
                }
                else if (i == 1){
                    buff[7] = buff[7] | B1B7C1;
                    buff[8] = buff[8] | B1B8C2;
                    buff[8] = buff[8] | B1B8C3;
                }
                else if (i == 2){
                    buff[7] = buff[7] | B2B7C1;
                    buff[8] = buff[8] | B2B8C2;
                    buff[8] = buff[8] | B2B8C3;
                }
                break;
        }

    // set inverted
    buff[6] = buff[7] >> 4;             // C1
    buff[6] = buff[6] | (buff[8] << 4); // C2
    buff[6] = ~buff[6];                 // invert

    buff[7] = buff[7] & 0xf0;
    buff[7] = buff[7] | ((~buff[8] >> 4) & 0x0f);   //~c3

    // add keys
    for (i = 0;i< sizeof(KEYA);i++){
             buff[i] = KEYA[i];
             buff[i+10] = KEYB[i];
         }

    if (debug){
        p_printf(GREEN,"New trailer to be written : ");
        for (i = 0;i<16;i++)
            p_printf(WHITE,"%02x",buff[i]);
        p_printf(WHITE,"\n");
    }
    // update trailer
    if (PcdWrite(t_addr, buff) != TAG_OK){
        p_printf(RED,"Error during writing trailer %d.\n", t_addr);
        PcdHalt();
        return(1);
    }

    // read back to double check
    if (debug)
    {   read_tag_str(t_addr,buff);
       p_printf(YELLOW, "Trailer %d has been read and has the following content %s\n",t_addr, buff);
    }

    // close / disconnect the card
    PcdHalt();
    p_printf(GREEN,"Permissions have been updated. You can remove the card\n");
    return(0);
}
/* read a specific block from the card */

int read_from_card(){

    int     addr = -1, i;
    unsigned char   ch;
    unsigned char 	buff[50];

    do    // get valid block
    {
        p_printf (YELLOW,"Please provide the block (Max %d) to read (99 = return) : ", max_page);
        addr = get_number();

        if (addr == 99)  return(0);

        if (addr > max_page) {
            p_printf(RED,"Block number is to high %2d. Maximum %d\n",addr, max_page);
            addr = -1;

        } else if (addr < 0){
            p_printf(RED,"Block can't be below 0.\n");
            addr = -1;
        }

    } while (addr == -1);

    ch = get_card_permission(addr);

    if (ch < 0) return(1);

    // as we use keyA for access, bit 1 should not be set, unless the value is 1
    // see MF1IC520 card description.

    if ((ch &0x01) && (ch != 1) ){
        p_printf(RED,"The block %d has no read permission. (%x) \n", addr,ch);
        PcdHalt();
        return(1);
    }

    // access memory block
    if (authorize(SN, addr,PICC_AUTHENT1A) != TAG_OK) return(1);

    // read block
    if (read_tag_str(addr,buff) == TAG_OK)
    {
	    // display block
	    p_printf(GREEN,"\nBlock %d has content: ",addr);
	
		for(i = 0; i<32; i++)
		{
			if(i> 0 &&  ! (i%2)) p_printf(WHITE,".");
			
			p_printf(YELLOW,"%c",buff[i]);
		}
		
		p_printf(WHITE,"\n");
		
    }
	else
		p_printf(RED, "Error during reading block %d\n",addr);
  
	if ((addr == 3) || (! ((addr-3) % 4)))
		p_printf (RED,"Be aware that you can NEVER read KEYA value (always zero's) from the trailer.\n");
    
    // close / disconnect the card
    PcdHalt();
    return(0);
}

/* write to specific block on the card */
int write_to_card(){

    int             numb, addr = -1;
    unsigned char   ch;
    int             value;
    unsigned char   buff[50];
    int             i, tmp, lp = 1;
    uint8_t         uvalue[20];

    do    // get valid block
    {
        p_printf (YELLOW,"Please provide the block to write to (Max %d) : ", max_page);
        addr=get_number();

        if (addr == 99)  close_out(0);

        if (addr > max_page) {
            p_printf(RED,"Block number is to high %2d. Maximum %d\n",addr, max_page);
            addr = -1;

        } else if (addr < 1){
            p_printf(RED,"Block can't be below 1.\n");
            addr = -1;
        }

        else if ((addr == 3) || (! ((addr-3) % 4))){
            p_printf (RED,"Can not write to trailer.\n");
            addr = -1;
        }

    } while (addr == -1);

    do    // get valid value
    {
        // clear buffer
        memset(uvalue, 0x0,sizeof(uvalue));


        p_printf (YELLOW,"How many bytes you like to store (max 16 bytes) :");
        numb=get_number();

        if ((numb < 0) || (numb > 16))
        {
            p_printf(RED,"Incorrect number of bytes. Try again.\n");
            continue;
        }

        for (i=0 ; i < numb; i++)
        {
            do
            {
                p_printf (WHITE, "Provide byte %2d : 0x",i);

                tmp = scanf("%x", &value);
 
                if (tmp == 0)
                    p_printf(RED,"Invalid entry. Try again.\n");
                else
                    uvalue[i] = (uint8_t) value;

                // flush any input pending
                while ((ch=getchar()) != '\n' && ch != EOF);

            } while (tmp == 0);
        }

        p_printf (GREEN,"You entered : ");
        for (i=0 ; i< numb; i++)  p_printf (WHITE, "0x%x ",uvalue[i]);

        p_printf(YELLOW,"\nIs this corrrect (y or n) ? ");
        ch = get_charc();
        if (ch == 'Y')  lp = 0;

    } while (lp); // get value

    if ((ch = get_card_permission(addr)) < 0) return(1);

    // as we use keyA for access, the only value is 0x0
    if (ch != 0){
        p_printf(RED,"The block %d has no write permission. (%x) \n", addr,ch);
        PcdHalt();
        return(1);
    }

    // access memory block
    if (authorize(SN, addr,PICC_AUTHENT1A) != TAG_OK) return(1);

    // perform write
    if (PcdWrite(addr, uvalue) != TAG_OK){
        p_printf(RED,"Error during writing.\n");
        PcdHalt();
        return(1);
    }

    // read back to double check
    read_tag_str(addr,buff);
    p_printf(GREEN, "Block %d: now has the following content %s.\n",addr, buff);

    // close / disconnect the card
    PcdHalt();
    return(0);
}
/* read card into a temp-file */

int read_card_to_file()
{
    FILE    * fmem_str;            // saving card information
    char    file_str[255];         // save filename
    char    *p;
    char    status;
    int     lp,errcnt=0;
	unsigned char    str[255];      // read config file
    
    
    p=file_str;
    sprintf(p,"%s",fmem_path);      // copy Path
    
    p+=strlen(p);
    
    for (lp=0;lp<SN_len;lp++) {     // add serial number
        sprintf(p,"%02x",SN[lp]);
        p+=2;
    }
    sprintf(p,".txt");              // add .txt

    if ((fmem_str=fopen(file_str,"r"))!= NULL) {
        p_printf(RED,"Not saving. File exists %s\n",file_str);
        fclose(fmem_str);
        return(TAG_ERR);
    }                               // Try to create file

    if ((fmem_str=fopen(file_str,"w"))== NULL)
    {
        p_printf(RED,"Not saving. Can not create for writing %s\n",file_str);
        return(TAG_ERR);
    }
    else
    {
                                     // save card memory
        p_printf(RED,
        "\n****************************************\n"
        "  Started reading... do not remove card.\n"
        "****************************************\n\n");

        status=TAG_OK;

        for (lp = 0; lp < max_page+1; lp+=page_step) {

                p_printf(WHITE,"now reading block %d\r",lp);

                if (authorize(SN,lp,PICC_AUTHENT1A) != TAG_OK)
                {
					errcnt++;
					fprintf(fmem_str,"%02d: %s\n",lp,"Authentification error");
					
					// try to recover (expect impact 4 blocks = 1 sector)
					Pcd_stopcrypto1();
					find_tag(&CType);
					select_tag_sn(SN,&SN_len);
                }
                else
                {
                    read_tag_str(lp,str);
                    fprintf(fmem_str,"%02d: %s\n",lp,str);
				}
        }
        
        fclose(fmem_str);

        if(errcnt == 0 )
        {
            p_printf(GREEN,"All done. You can remove card.\n"
            "Content read is saved in %s\n",file_str);
        }
        else 
        {
            p_printf(RED, "\n%d error(s) during reading.\n"
			"Any content read is saved in %s\n",errcnt, file_str);
			status =TAG_ERR;
        }
    }
    return(status);
}

/* perform action based on card UID or block content number */

int perform_action()
{
    pid_t child;                    // execute command
    int tmp, i;
    char    str[255];  
									// look for match to serial number
    if (find_config_param(sn_str,str,sizeof(str),1)>0)
    {
        child=fork();               // if found : create child
        
        if (child == 0) 			
        {
            fclose(stdin);
            freopen("","w",stdout);
            freopen("","w",stderr); // execute command
            execl("/bin/sh","sh","-c",str,NULL);
        } 
        
        else if (child > 0) {  		// parent      
            
            i=6000;					// wait max 1 minute
            
            do {
                usleep(10000);
                tmp = wait3(NULL,WNOHANG,NULL);
                i--;
            } while (i>0 && tmp != child);

            if (tmp != child) 
            {
                kill(child,SIGKILL);
                wait3(NULL,0,NULL);
                
                p_printf(RED,"Killed\n");
                
                return(1);
            }
            else 
            {
                p_printf(BLUE,"Exit\n");
                return(0);
			}
        }
        else
        {
            p_printf(RED,"Can't run child process! (%s %s)\n",sn_str,str);
            return(1);
        }
     }
     else
        p_printf(YELLOW, "No action found in %s for number %s\n",config_file,sn_str);

     return(2);
}

/* wait for card, read card type and serial number */

int get_card_info()
{
    int 	status;
    int 	cnt = 0;
    char	ch;

    p_printf(BLUE,"Hold your card for the reader ");

    do
    {
        status = find_tag(&CType);

        if (cnt++ > 3){                 // display keep alive
            cnt = 0;
            p_printf(BLUE,".");
        }

        if (status == TAG_NOTAG) {     // no card (wait 2 seconds))
            usleep(200000);
            continue;
        }
        else if                        // issue with tag reading ?
        (status != TAG_OK && status != TAG_COLLISION)
            continue;
                                        // read serial number
        status = select_tag_sn(SN, &SN_len);

    } while (status != TAG_OK);

    p_printf(GREEN,"card found.\n");

	// determine memory details
	switch (CType) {
		case 0x4400:           // 16 blocks of 8 bytes
			max_page=0x0f;
			page_step=4;       // increment to read the card
			break;
		case 0x0400:           // 64 blocks of 16 bytes / Ul card
			max_page=0x3f;
			page_step=1;       // increment to read the card
			break;
		default:
			p_printf(YELLOW,"Card type not known. Do you want to continue ? ( y/n ) ");
			ch = get_charc();

			if (ch != 'Y'){
				PcdHalt();
				close_out(1);
			}
			break;
	}
	
    return(status);

}

/* catch signals to close out correctly */
void signal_handler(int sig_num)
{
	p_printf(YELLOW, "\nStopping Reader.\n");
	close_out(2);
}


/* setup signals */
void set_signals()
{
	struct sigaction act;
	
	memset(&act, 0x0,sizeof(act));
	act.sa_handler = &signal_handler;
	sigemptyset(&act.sa_mask);
	
	sigaction(SIGTERM,&act, NULL);
	sigaction(SIGINT,&act, NULL);
	sigaction(SIGABRT,&act, NULL);
	sigaction(SIGSEGV,&act, NULL);
	sigaction(SIGKILL,&act, NULL);
}


int main(int argc, char *argv[]) {

    char    *p;
    int     tmp;
    int     d_write = 0,d_read = 0, action=0, change=0, add_act=0;
    int     option = 0, upd_key=0;

    while ((option = getopt(argc,argv,"achksrdpwn")) != -1) {
        switch(option) {
            case 'h' : {usage(argv[0]); exit(0);}
                break;
            case 'd' : {debug = 1;p_printf(YELLOW,"Debug mode.\n");}
                break;
            case 'w' : d_write = 1;
                break;
            case 'a' : add_act = 1;
                break;
            case 's' : save_mem = 1;
                break;
            case 'k' : upd_key = 1;
                break;
            case 'r' : d_read = 1;
                break;
            case 'p' : action = 1;
                break;
            case 'c' : change = 1;
                break;
            case 'n' : NoColor = 1;
                break;
            default  : {usage(argv[0]); exit(1);}
        }
    }

	// must be run as root to open /dev/mem in BMC2835
    if (geteuid() != 0){
        p_printf(RED,"Must be run as root.\n");
        exit(1);
    }
    
    // catch signals
	set_signals();
	    
    /* read /etc/rc522.conf */
    if (get_config_file()) exit(1);

    /* set BCM2835 Pins correct */
    if (HW_init(spi_speed,gpio)) close_out(1);
    
    /* initialise the RC522 */
	InitRc522();

    /* read & set GID and UID from config file */
    if (read_conf_uid()!= 0) close_out(1);
  

    // uncomment for extra debug info
/*
    if (debug){
        printf("before loop:\nloop = %d, debug = %d, gpio = %d, spi_speed = %d\n", loop, debug,gpio, spi_speed);
        printf("NotEndless = %d, fmem_path = %s, save_mem = %d\n",NotEndless, fmem_path, save_mem);
        printf("d_read = %d, d_write = %d, add_act = %d, upd_key = %d\n", d_read, d_write, add_act, upd_key);
    }
*/
    while (loop > 0){

        if (NotEndless)
            p_printf(WHITE, "\nWill still handle %d card(s)\n", loop);

        /* read a specific card block */
        if (d_read){ if (read_from_card()) close_out(1); }
        
        /* write a specific card block */
        else if (d_write){ if(write_to_card()) close_out(1); }
        
        /* perform action based on info in a specific card block */
        else if (add_act){ if (addr_action()) close_out(1); }
        
        /* change access right on a specific card block */
        else if (change){ if (change_con()) close_out(1); }
        
        /* update a key on specific sector */
        else if (upd_key){ if (key_upd()) close_out(1);}

        else 
        {
            // wait for card
            while (get_card_info() != TAG_OK) usleep(5000);

			// create serial string
            p=sn_str;                       
            *(p++)='[';                     // start with [
            for (tmp=0;tmp<SN_len;tmp++) {  // add serial number
                sprintf(p,"%02x",SN[tmp]);
                p+=2;
            }
            *(p++)=']';                     // close out with ]
            *(p++)=0;

            //for debugging
            if (debug)
                p_printf(WHITE,"Tag: type=%04x SNlen=%d SN=%s\n",CType,SN_len,sn_str);

            // save memory of card ??
            if (save_mem)   read_card_to_file();

            // find match to serial number string in config file
            else if (action) perform_action();
            
            else
               p_printf(WHITE,"Tag: type=%04x SNlen=%d SN=%s\n",CType,SN_len,sn_str);

            p_printf(YELLOW,"Please remove card\n");
            sleep(2);
            
            // close / disconnect the card
            PcdHalt();
        }
		// count this card
        if (NotEndless)    loop--;
    }   // loop

    close_out(0);
    
    // stop Wall complaining
    exit(0);
}
