/*
 * main.h
 *
 *  Created on: 26.09.2013
 *      Author: alexs
 * 
 * version 1.50 / paulvh / July 2017
 * Fixed number of bugs and code clean-up.
 */

#ifndef MAIN_H_
#define MAIN_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <syslog.h>
#include <sys/wait.h>
#include <signal.h>
#include <stdarg.h>
#include <string.h>
#include <bcm2835.h>
#include <ctype.h>
#include "rfid.h"


// color display enable
#define RED 	1
#define GREEN 	2
#define YELLOW  3
#define BLUE	4
#define WHITE	5

#define REDSTR "\e[1;31m%s\e[00m"
#define GRNSTR "\e[1;92m%s\e[00m"
#define YLWSTR "\e[1;93m%s\e[00m"
#define BLUSTR "\e[1;34m%s\e[00m"

/* different routines in main.c */

/* calculate sector number based on block */
int calc_sector_number(int block);

/* determine block trailer */
int calc_block_trailer(int addr);

int get_card_info();
int authorize(uint8_t *pSnr, int block, int auth_key);
int perform_action();
int change_con();
void close_out(int ex_code);
int get_card_info();
int get_card_permission(int addr);
int get_config_file();
int key_upd();
int read_card_to_file();
int read_from_card();
void usage(char * str);
int write_to_card();
void p_printf (int level, char *format, ...);

extern uint8_t debug;
extern uint8_t SN[10];             // serial number of card
extern uint8_t SN_len;           // length of serial number ( 4/7/10)

/**
 * For details see MF1ICS50_rev5_3.pdf
 * 
 * Each sector (max 16) has 4 blocks. (block 0 - 3)
 * Block 3 is the trailer and contains
 * 6 bytes KEYA
 * 4 bytes access bits
 * 6 bytes KEYB (optional)
 * 
 *  
 * The access bytes are stored in BYTE 6 ,7 8 in the trailer
 *  Cx-y =  access control bit x for block y 
 * [Cx-y] = inverted access control bit x for block y (between brackets)
 * 
 * 
 *     bit  7      6      5       4      3      2     1      0    
 * BYTE 6 [C2-3] [C2-2] [C2-1] [C2-0] [C1-3] [C1-2] [C1-1] [C1-0]
 * BYTE 7  C1-3   C1-2   C1-1   C1-0  [C3-3] [C3-2] [C3-1] [C3-0]
 * BYTE 8  C3-3   C3-2   C3-1   C3-0   C2-3   C2-2   C2-1   C2-0
 * BYTE 9  not used
 * 
 * FOR THE TRAILER ONlY:
 * It will indicate whether read/write access is with KEYA, KEYB, either KEYA or KEYB 
 * It is depending on the combination of the bits C1-3 , C2-3, C3-3
 * If new delivered the status bits are  0  0 1 and as such KEYA can be used to read and write all.
 * 
 * FOR BLOCK 0,1, 2
 * Depending on access bits for each block the read/write access is either with KEYA, 
 * KEYB, either KEYA or KEYB of never. It also indicates whether the block is a data or value block
 * 
 * For details see MF1ICS50_rev5_3.pdf
 * 
 * To extract the correct access bits the:
 * 
 * BxByCz = BLOCK x, from BYTE y, CONTROLbit z
 * 
 */ 

#define B0B7C1 0X10 // B0 = block 0, B7 = Byte 7, C1 = condition 1
#define B0B8C2 0X01
#define B0B8C3 0X10

#define B1B7C1 0X20
#define B1B8C2 0X02
#define B1B8C3 0X20

#define B2B7C1 0X40
#define B2B8C2 0X04
#define B2B8C3 0X40

#define TB7C1 0X80  // T = Trailer, B7 = Byte 7, C1 = condition 1
#define TB8C2 0X08
#define TB8C3 0X80


#endif /* MAIN_H_ */
