/*
 * config.h
 *
 *  Created on: 05.09.2013
 *      Author: alexs
 * 
 * version 1.50 / paulvh / July 2017
 * Fixed number of bugs and code clean-up.
 */

#ifndef CONFIG_H_
#define CONFIG_H_

#define DEBUG 0

#include "main.h"

#define default_config_file "/etc/RC522.conf"

extern char config_file[255];
int read_conf_uid();
int open_config_file(char *);
void close_config_file();
int find_config_param(char *, char *, int, int);
int read_conf_key(int addr, int auth_key);
int add_to_config(char *buf);

extern uint8_t KEYA[6];
extern uint8_t KEYB[6];

#endif /* CONFIG_H_ */
